/* =====================================================================
   VideoGuide — "Saytdan qanday foydalanish kerak? (Video qoʻllanma)"
   Manba: EM_CONFIG.VIDEO[locale] = { src, poster, captions }
   src yoʻq boʻlsa — "Video tez orada qoʻshiladi" holati va 3 qadamli yoʻriqnoma.
   Pleyer: 16:9, playsinline, preload=metadata, ijro/pauza, ovoz, toʻliq ekran,
           subtitr, klaviatura (Space/K, M, F, C, ←/→).
   ===================================================================== */
window.EM_Video = (function () {
  "use strict";
  const CFG = window.EM_CONFIG, I = window.EM_I18N;
  const esc = function (s) { return window.EM_DOC.esc(s); };

  function fmt(sec) {
    sec = Math.max(0, Math.floor(sec || 0));
    return Math.floor(sec / 60) + ":" + String(sec % 60).padStart(2, "0");
  }

  function placeholder() {
    return '<div class="vg-frame vg-soon" role="img" aria-label="' + esc(I.t("video.soon")) + '">' +
      '<div class="vg-soon-inner"><span class="vg-soon-icon" aria-hidden="true">▶</span>' +
      "<b>" + esc(I.t("video.soon")) + "</b>" +
      "<p>" + esc(I.t("video.soonLead")) + "</p>" +
      '<ol class="vg-steps"><li>' + esc(I.t("video.s1")) + "</li><li>" + esc(I.t("video.s2")) + "</li><li>" + esc(I.t("video.s3")) + "</li></ol>" +
      "</div></div>";
  }

  function player(v) {
    return '<div class="vg-frame vg-player" tabindex="0">' +
      '<video playsinline preload="metadata"' + (v.poster ? ' poster="' + esc(v.poster) + '"' : "") + ">" +
      '<source src="' + esc(v.src) + '">' +
      (v.captions ? '<track kind="captions" src="' + esc(v.captions) + '" srclang="' + esc(I.locale) + '" label="' + esc(I.t("video.captions")) + '">' : "") +
      "</video>" +
      '<div class="vg-controls">' +
      '<button type="button" class="vg-btn vg-play" aria-label="' + esc(I.t("video.play")) + '">▶</button>' +
      '<input type="range" class="vg-seek" min="0" max="1000" value="0" aria-label="' + esc(I.t("video.seek")) + '">' +
      '<span class="vg-time" aria-live="off">0:00 / 0:00</span>' +
      '<button type="button" class="vg-btn vg-mute" aria-label="' + esc(I.t("video.mute")) + '">🔊</button>' +
      '<input type="range" class="vg-vol" min="0" max="1" step="0.05" value="1" aria-label="' + esc(I.t("video.volume")) + '">' +
      (v.captions ? '<button type="button" class="vg-btn vg-cc" aria-pressed="true" aria-label="' + esc(I.t("video.captions")) + '">CC</button>' : "") +
      '<button type="button" class="vg-btn vg-fs" aria-label="' + esc(I.t("video.fullscreen")) + '">⛶</button>' +
      "</div></div>";
  }

  function wire(root) {
    const frame = root.querySelector(".vg-player");
    if (!frame) return;
    const v = frame.querySelector("video");
    const play = frame.querySelector(".vg-play"), seek = frame.querySelector(".vg-seek"), time = frame.querySelector(".vg-time");
    const mute = frame.querySelector(".vg-mute"), vol = frame.querySelector(".vg-vol"), fs = frame.querySelector(".vg-fs"), cc = frame.querySelector(".vg-cc");
    const sync = function () {
      play.textContent = v.paused ? "▶" : "❚❚";
      play.setAttribute("aria-label", I.t(v.paused ? "video.play" : "video.pause"));
      mute.textContent = v.muted || v.volume === 0 ? "🔇" : "🔊";
      mute.setAttribute("aria-label", I.t(v.muted ? "video.unmute" : "video.mute"));
      if (v.duration) { seek.value = String(Math.round(v.currentTime / v.duration * 1000)); time.textContent = fmt(v.currentTime) + " / " + fmt(v.duration); }
    };
    const toggle = function () { if (v.paused) v.play().catch(function () {}); else v.pause(); };
    play.addEventListener("click", toggle);
    v.addEventListener("click", toggle);
    ["play", "pause", "timeupdate", "loadedmetadata", "volumechange"].forEach(function (e) { v.addEventListener(e, sync); });
    seek.addEventListener("input", function () { if (v.duration) v.currentTime = seek.value / 1000 * v.duration; });
    mute.addEventListener("click", function () { v.muted = !v.muted; });
    vol.addEventListener("input", function () { v.volume = Number(vol.value); v.muted = v.volume === 0; });
    fs.addEventListener("click", function () {
      if (document.fullscreenElement) document.exitFullscreen(); else (frame.requestFullscreen || frame.webkitRequestFullscreen || function () { v.webkitEnterFullscreen && v.webkitEnterFullscreen(); }).call(frame);
    });
    if (cc) cc.addEventListener("click", function () {
      const tr = v.textTracks[0]; if (!tr) return;
      const on = tr.mode !== "showing"; tr.mode = on ? "showing" : "hidden"; cc.setAttribute("aria-pressed", String(on));
    });
    if (v.textTracks[0]) v.textTracks[0].mode = "showing";
    v.addEventListener("error", function () { frame.outerHTML = '<div class="vg-frame vg-soon"><div class="vg-soon-inner"><b>' + esc(I.t("video.error")) + "</b></div></div>"; });
    frame.addEventListener("keydown", function (e) {
      if (e.target.tagName === "INPUT") return;
      const k = e.key.toLowerCase();
      if (k === " " || k === "k") { e.preventDefault(); toggle(); }
      else if (k === "m") v.muted = !v.muted;
      else if (k === "f") fs.click();
      else if (k === "c" && cc) cc.click();
      else if (k === "arrowright") v.currentTime = Math.min(v.duration || 0, v.currentTime + 5);
      else if (k === "arrowleft") v.currentTime = Math.max(0, v.currentTime - 5);
    });
  }

  function render(host) {
    const v = CFG.VIDEO[I.locale] || {};
    host.innerHTML = '<h2 class="vg-title"><span aria-hidden="true">🎬</span> ' + esc(I.t("video.title")) + "</h2>" + (v.src ? player(v) : placeholder());
    wire(host);
  }

  function mountAll() { document.querySelectorAll("[data-video-guide]").forEach(render); }
  document.addEventListener("em:langchange", mountAll);
  return { mountAll: mountAll };
})();
