/* =====================================================================
   E-murojat — YAGONA KONFIGURATSIYA
   Brend nomi, tillar, cheklovlar va video manbalari shu yerda.
   ===================================================================== */
window.EM_CONFIG = Object.freeze({
  BRAND_NAME: "E-murojat",

  // Server API (bir xil manbadan). file:// orqali ochilganda server boʻlmaydi → lokal rejim.
  API_BASE: "",

  LOCALES: [
    { code: "uz-Latn", label: "OʻZ", name: "Oʻzbekcha", htmlLang: "uz-Latn" },
    { code: "uz-Cyrl", label: "ЎЗ", name: "Ўзбекча", htmlLang: "uz-Cyrl" },
    { code: "ru", label: "РУ", name: "Русский", htmlLang: "ru" },
    { code: "kaa", label: "ҚҚ", name: "Қарақалпақша", htmlLang: "kaa" },
    { code: "en", label: "EN", name: "English", htmlLang: "en" }
  ],
  DEFAULT_LOCALE: "uz-Latn",

  ATTACHMENTS: {
    maxFileMB: 10,
    maxFiles: 10,
    maxTotalMB: 50,
    accept: "image/*,application/pdf",
    mimePrefixes: ["image/"],
    mimeExact: ["application/pdf"],
    extensions: ["jpg", "jpeg", "png", "webp", "heic", "heif", "gif", "pdf"]
  },

  VOICE: {
    maxSeconds: 120,
    mimeCandidates: ["audio/webm;codecs=opus", "audio/webm", "audio/mp4", "audio/aac"]
  },

  TEXT: { minChars: 20, maxChars: 6000 },

  // Video qoʻllanma: har til uchun { src, poster, captions }. src = null → "Video tez orada qoʻshiladi".
  VIDEO: {
    "uz-Latn": { src: null, poster: null, captions: null },
    "uz-Cyrl": { src: null, poster: null, captions: null },
    "ru": { src: null, poster: null, captions: null },
    "kaa": { src: null, poster: null, captions: null },
    "en": { src: null, poster: null, captions: null }
  },

  STORAGE_KEYS: { locale: "emurojat_locale", draft: "emurojat_draft", history: "emurojat_history" }
});
