# PROGRESS — E-murojat (LexHakaton MVP)

> **Qoida:** har bir muhim qadamdan keyin shu fayl yangilanadi. Yangi sessiyada ishni boshlashdan oldin avval shu faylni, `docs/DECISIONS.md` ni va mavjud fayllarni oʻqing. Mavjud kodni qaytadan yozmang.

**Oxirgi yangilanish:** 2026-11-20 (3-bosqich: topshiriq boʻyicha toʻliq yangilanish)

## ✅ Tayyor
| Qism | Fayllar | Holati |
|---|---|---|
| Brend va glossariy | `js/config.js` (`BRAND_NAME`), `js/i18n/glossary.js` (`§B`, `§m`, `§M` tokenlari) | "E-murojat" hamma joyda yagona konstantadan olinadi. Qonunlarning rasmiy nomlari oʻzgartirilmagan |
| Imlo | `js/lib/uzNormalize.js` (ʻ U+02BB, ʼ U+02BC), `js/lib/translit.js` | Unit testlar bilan qoplangan |
| 5 til | `js/i18n/uz-Latn.js`, `ru.js`, `en.js`, `uz-Cyrl.js`, `kaa.js` (kirill; ikkalasi `scripts/gen_i18n.py` orqali hosil qilinadi), `i18n.js` | 351 kalit, barcha tillarda kalitlar mos. ЎЗ tanlanganda interfeys va hujjat kirillda (e2e tekshiradi) |
| Titul varaq | `index.html`, `css/landing.css`, `css/flow.css`, `js/components/videoGuide.js`, `languageSwitcher.js` | Motion effektlar saqlangan. Video qoʻllanma (manba yoʻq → "tez orada" + 3 qadam). Tor ekranda til tugmalari ixcham roʻyxatga oʻtadi |
| 1-qadam: profil | `js/components/applicantDialog.js`, `js/data/regions.js`, `js/lib/validators.js` | F.I.Sh. (≥2 soʻz), viloyat → tuman, manzil, +998 maskasi / e-pochta. "Davom etish" faqat toʻgʻri toʻldirilganda faol |
| 2-qadam: kiritish | `js/components/appealComposer.js`, `voiceInput.js`, `attachmentList.js` | Chat qatori (avtomatik kengayadi), namunalar, 56px mikrofon (avval matn → tasdiq), fayl/kamera (tur, hajm, son tekshiruvi), aniqlashtiruvchi savollar (1–3) |
| Tasniflash | `js/ai/client.js`, `js/data/categories.js` (14 soha), `server/classify.py`, `server/ai_provider.py` | AI (server, kalit `.env` da) yoki lokal qoidalar. Shaxsiy maʼlumotlar yashiriladi, javob sxema bilan tekshiriladi |
| 3-qadam: 5 natija oynasi | `js/components/resultPanels.js`, `js/data/organizations_db.js`, `legal_basis_db.js`, `js/lib/validateAppeal.js`, `docTemplate.js`, `docExport.js` | Organ (tuman → viloyat → respublika fallback), shakl va ilovalar, qonunlar va tekshiruv (oʻtdi/tuzat), 7 boʻlimli hujjat (nusxa/DOCX/chop etish), javob muddati va eskalatsiya |
| Server | `server/server.py` (+ `.env.example`, `requirements.txt`) | Statik fayllar (maxfiy papkalar yopiq), `/api/health`, `/api/classify`, `/api/transcribe` (stub), rate-limit |
| Testlar | `tests/unit.html` + `unit.js` (114 ✓), `server/test_server.py` (11 ✓), `tests/e2e.py` (Playwright: 10/10 oqim, 320–768px da maket muammosi 0) | Barchasi oʻtadi |
| Hujjatlar | `docs/PLAN.md`, `DECISIONS.md`, `I18N_REVIEW.md`, `MOBILE_WEBVIEW.md`, `README.md` | Tayyor |

## ⚠ Inson tekshiruvi kerak / chala
- **Organlar bazasi:** barcha yozuvlar `verified: false`. Manzil, telefon va sayt yoʻq; hududiy nomlar qolipdan hosil qilingan.
- **Qonunlar:** modda raqamlari boʻsh (`articles: []`). Muddat (15 kun / 30 kungacha, kalendar kuni) tasdiqlanmagan.
- **Hududlar roʻyxati** xotiradan tuzilgan — rasmiy roʻyxat bilan solishtirish kerak.
- **Tarjimalar:** qoraqalpoq tili toʻliq tekshirilishi shart; uz-Cyrl, ru va en ham koʻrib chiqilishi kerak (`docs/I18N_REVIEW.md`).
- **STT provayderi** ulanmagan (stub). **Video manbasi** yoʻq. **AI** haqiqiy kalit bilan sinalmagan.
- **WebView** qurilmada sinalmagan (`docs/MOBILE_WEBVIEW.md`).
- **Git yoʻq:** commit qilinmagan; zaxira nusxalar `backups/` papkasida.
- `assets/logo-full.png` va `hero-reference.png` rasmlari ichida eski "E-murojaat" yozuvi bor (rasm, matn emas). Interfeysda faqat `logo-mark.png` (yozuvsiz) ishlatiladi.

## ➡ Keyingi qadamlar
1. Organlar va qonun moddalarini rasmiy manbalardan toʻldirish (`verified: true`, `sources`, `lastVerified`).
2. Haqiqiy STT provayderini `server/stt.py` ga ulash; AI'ni haqiqiy kalit bilan sinash.
3. Tarjimalarni ona tili egalari bilan tekshirish; video qoʻllanmani yozib, `config.js` ga qoʻshish.
4. Git repozitoriy ochib, `feature/e-murojat-update` branchiga commit qilish.

## 📌 Muhim qarorlar
Batafsil: `docs/DECISIONS.md`. Asosiylari:
- Stek oʻzgarmadi: vanilla JS + Python server (Node yoʻq).
- AI kaliti faqat serverda.
- `murojat` atamasi glossariyda; qonun nomlari esa rasmiy shaklda.
- Uydirma maʼlumot yoʻq: tasdiqlanmagan maʼlumotlar interfeysda "tekshirilsin" deb koʻrsatiladi.

## 🕒 Jurnal
- **2026-11-20 (1)** — MVP yaratildi (forma + 4 kartochka, DOCX, chop etish).
- **2026-11-20 (2)** — Motion effektli titul varaq va 4 til qoʻshildi.
- **2026-11-20 (3)** — Topshiriq boʻyicha yangilash:
  - brend "E-murojat";
  - 5 til (ЎЗ va qoraqalpoq kirill);
  - 3 qadamli oqim (profil → kiritish → natija);
  - 14 soha, ovoz, fayllar, 5 natija oynasi;
  - organlar va qonunlar bazasi, server, testlar va hujjatlar.

  Eski `js/ai.js`, `js/i18n.js` va `js/knowledge*.js` fayllari `backups/legacy-js/` ga koʻchirildi.
