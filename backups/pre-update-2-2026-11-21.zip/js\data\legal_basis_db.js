/* =====================================================================
   legal_basis_db — qonunchilik asoslari bazasi
   Har bir yozuv: { id, title{…til…}, summary{…til…}, articles: [], source{title,url},
                   verified, verifiedAt }
   ⚠ Modda raqamlari va muddat shartlari bu muhitda rasmiy manba bilan
   TASDIQLANMAGAN → articles: [] va verified: false. AI xotirasidan modda
   raqami olinmaydi. Tasdiqlangach shu yerga yoziladi (masalan: articles: ["10-modda"]).
   ===================================================================== */
window.EM_LAWS = (function () {
  "use strict";
  const LEX = { titleKey: "src.lex", title: "lex.uz — Qonunchilik maʼlumotlari milliy bazasi (qidiruv orqali tekshirilsin)", url: "https://lex.uz" };

  function law(id, uz, ru, en, sUz, sRu, sEn) {
    return { id: id, title: { "uz-Latn": uz, ru: ru, en: en }, summary: { "uz-Latn": sUz, ru: sRu, en: sEn },
      articles: [], source: LEX, verified: false, verifiedAt: null };
  }

  const LAWS = {
    appeals: law("appeals",
      "Oʻzbekiston Respublikasining “Jismoniy va yuridik shaxslarning murojaatlari toʻgʻrisida”gi Qonuni",
      "Закон Республики Узбекистан «Об обращениях физических и юридических лиц»",
      "Law of the Republic of Uzbekistan “On Appeals of Individuals and Legal Entities”",
      "Murojat qilish tartibi, unga qoʻyiladigan talablar (F.I.Sh., yashash joyi, mohiyat, elektron murojatda — aloqa maʼlumotlari), koʻrib chiqish muddatlari va javob berish majburiyatini belgilaydi. Anonim murojatlar koʻrib chiqilmaydi.",
      "Определяет порядок подачи обращений, требования к ним (Ф.И.О., место жительства, суть, для электронных — контакты), сроки рассмотрения и обязанность дать ответ. Анонимные обращения не рассматриваются.",
      "Sets the procedure for appeals, their requirements (full name, residence, substance, contact details for online appeals), time limits and the duty to reply. Anonymous appeals are not considered."),
    labor_code: law("labor_code", "Oʻzbekiston Respublikasining Mehnat kodeksi", "Трудовой кодекс Республики Узбекистан", "Labor Code of the Republic of Uzbekistan",
      "Ish beruvchi ish haqini belgilangan muddatlarda va toʻliq miqdorda toʻlashi shart; kechiktirilganda xodim himoyalanish va kompensatsiya olish huquqiga ega; mehnat nizolarini hal etish tartibi belgilangan.",
      "Работодатель обязан выплачивать зарплату в срок и в полном объёме; при задержке работник вправе на защиту и компенсацию; установлен порядок разрешения трудовых споров.",
      "The employer must pay wages on time and in full; on delay the employee is entitled to protection and compensation; the procedure for labor disputes is set out."),
    consumer: law("consumer", "Oʻzbekiston Respublikasining “Isteʼmolchilarning huquqlarini himoya qilish toʻgʻrisida”gi Qonuni", "Закон Республики Узбекистан «О защите прав потребителей»", "Law of the Republic of Uzbekistan “On Protection of Consumer Rights”",
      "Isteʼmolchi sifatli va xavfsiz tovar (xizmat) olish huquqiga ega; kamchilik aniqlanganda almashtirish, narxni kamaytirish, bepul tuzatish yoki pulni qaytarishni talab qilishi mumkin.",
      "Потребитель вправе получить качественный и безопасный товар (услугу); при недостатках может требовать замены, снижения цены, бесплатного устранения недостатков или возврата денег.",
      "The consumer is entitled to safe goods (services) of proper quality; if defects are found they may demand replacement, a price reduction, free repair or a refund."),
    civil_code: law("civil_code", "Oʻzbekiston Respublikasining Fuqarolik kodeksi", "Гражданский кодекс Республики Узбекистан", "Civil Code of the Republic of Uzbekistan",
      "Shartnomalar (oldi-sotdi, ijara, taʼminot), majburiyatlar, zararni qoplash va meros boʻyicha umumiy qoidalar.",
      "Общие правила о договорах (купля-продажа, аренда, снабжение), обязательствах, возмещении вреда и наследовании.",
      "General rules on contracts (sale, lease, supply), obligations, compensation for damage and inheritance."),
    banks: law("banks", "Oʻzbekiston Respublikasining “Banklar va bank faoliyati toʻgʻrisida”gi Qonuni", "Закон Республики Узбекистан «О банках и банковской деятельности»", "Law of the Republic of Uzbekistan “On Banks and Banking Activity”",
      "Banklar faoliyati, mijozlar bilan munosabatlar va Markaziy bank nazorati asoslari.",
      "Основы деятельности банков, отношений с клиентами и надзора Центрального банка.",
      "Basics of bank activity, client relations and Central Bank supervision."),
    traffic: law("traffic", "Oʻzbekiston Respublikasining “Yoʻl harakati xavfsizligi toʻgʻrisida”gi Qonuni", "Закон Республики Узбекистан «О безопасности дорожного движения»", "Law of the Republic of Uzbekistan “On Road Traffic Safety”",
      "Yoʻl harakati ishtirokchilarining huquq va majburiyatlari hamda yoʻl harakati xavfsizligini taʼminlash asoslari.",
      "Права и обязанности участников дорожного движения и основы обеспечения его безопасности.",
      "Rights and duties of road users and the basis of ensuring road safety."),
    admin_code: law("admin_code", "Oʻzbekiston Respublikasining Maʼmuriy javobgarlik toʻgʻrisidagi kodeksi", "Кодекс Республики Узбекистан об административной ответственности", "Code of Administrative Responsibility of the Republic of Uzbekistan",
      "Maʼmuriy huquqbuzarliklar, jarimalar va ularni qoʻllash hamda shikoyat qilish tartibi.",
      "Административные правонарушения, штрафы, порядок их применения и обжалования.",
      "Administrative offences, fines and the procedure for imposing and appealing them."),
    notary: law("notary", "Oʻzbekiston Respublikasining “Notariat toʻgʻrisida”gi Qonuni", "Закон Республики Узбекистан «О нотариате»", "Law of the Republic of Uzbekistan “On Notariat”",
      "Notarial harakatlarni amalga oshirish tartibi va notariuslar faoliyati ustidan nazorat.",
      "Порядок совершения нотариальных действий и контроль за деятельностью нотариусов.",
      "Procedure for notarial acts and supervision of notaries."),
    citizenship: law("citizenship", "Oʻzbekiston Respublikasining “Oʻzbekiston Respublikasining fuqaroligi toʻgʻrisida”gi Qonuni", "Закон Республики Узбекистан «О гражданстве Республики Узбекистан»", "Law of the Republic of Uzbekistan “On Citizenship of the Republic of Uzbekistan”",
      "Fuqarolikka qabul qilish, uni rasmiylashtirish va tegishli hujjatlar berish asoslari.",
      "Основания приобретения и оформления гражданства и выдачи документов.",
      "Grounds for acquiring and formalizing citizenship and issuing documents."),
    pension: law("pension", "Oʻzbekiston Respublikasining “Fuqarolarning davlat pensiya taʼminoti toʻgʻrisida”gi Qonuni", "Закон Республики Узбекистан «О государственном пенсионном обеспечении граждан»", "Law of the Republic of Uzbekistan “On State Pension Provision of Citizens”",
      "Pensiya tayinlash shartlari, uni hisoblash va toʻlash tartibi.",
      "Условия назначения пенсии, порядок её исчисления и выплаты.",
      "Conditions for granting pensions and the procedure for calculating and paying them."),
    health: law("health", "Oʻzbekiston Respublikasining “Fuqarolar sogʻligʻini saqlash toʻgʻrisida”gi Qonuni", "Закон Республики Узбекистан «Об охране здоровья граждан»", "Law of the Republic of Uzbekistan “On Protection of Citizens’ Health”",
      "Fuqarolarning tibbiy yordam olish huquqi, tibbiyot xodimlarining majburiyatlari va bemor huquqlarini himoya qilish asoslari.",
      "Право граждан на медицинскую помощь, обязанности медработников и основы защиты прав пациентов.",
      "Citizens’ right to medical care, duties of medical workers and protection of patients’ rights."),
    education: law("education", "Oʻzbekiston Respublikasining “Taʼlim toʻgʻrisida”gi Qonuni", "Закон Республики Узбекистан «Об образовании»", "Law of the Republic of Uzbekistan “On Education”",
      "Har kimning taʼlim olish huquqi, taʼlim muassasalari va pedagoglarning majburiyatlari kafolatlanadi.",
      "Гарантируются право на образование, обязанности учреждений и педагогов.",
      "Guarantees the right to education and the duties of institutions and teachers."),
    tax_code: law("tax_code", "Oʻzbekiston Respublikasining Soliq kodeksi", "Налоговый кодекс Республики Узбекистан", "Tax Code of the Republic of Uzbekistan",
      "Soliq toʻlovchilarning huquq va majburiyatlari, soliq tekshiruvlari va ular ustidan shikoyat qilish tartibi.",
      "Права и обязанности налогоплательщиков, налоговые проверки и порядок их обжалования.",
      "Taxpayers’ rights and duties, tax audits and the procedure for appealing them."),
    business: law("business", "Oʻzbekiston Respublikasining “Tadbirkorlik faoliyati erkinligining kafolatlari toʻgʻrisida”gi Qonuni", "Закон Республики Узбекистан «О гарантиях свободы предпринимательской деятельности»", "Law of the Republic of Uzbekistan “On Guarantees of Freedom of Entrepreneurial Activity”",
      "Tadbirkorlik subyektlarining huquqlari va ularni himoya qilish kafolatlari.",
      "Права субъектов предпринимательства и гарантии их защиты.",
      "Rights of business entities and guarantees of their protection."),
    nature: law("nature", "Oʻzbekiston Respublikasining “Tabiatni muhofaza qilish toʻgʻrisida”gi Qonuni", "Закон Республики Узбекистан «Об охране природы»", "Law of the Republic of Uzbekistan “On Nature Protection”",
      "Atrof-muhitni muhofaza qilish, fuqarolarning qulay atrof-muhitga boʻlgan huquqi va davlat nazorati asoslari.",
      "Охрана окружающей среды, право граждан на благоприятную среду и основы госконтроля.",
      "Environmental protection, citizens’ right to a healthy environment and state control."),
    local_gov: law("local_gov", "Oʻzbekiston Respublikasining “Mahalliy davlat hokimiyati toʻgʻrisida”gi Qonuni", "Закон Республики Узбекистан «О государственной власти на местах»", "Law of the Republic of Uzbekistan “On State Power in Localities”",
      "Hokimlarning hududni rivojlantirish, obodonlashtirish va aholi murojatlarini hal etish boʻyicha vakolatlari.",
      "Полномочия хокимов по развитию и благоустройству территории и решению обращений населения.",
      "Powers of khokims to develop the territory and resolve residents’ appeals.")
  };

  const BY_CATEGORY = {
    labor: ["labor_code"], consumer: ["consumer", "civil_code"], housing_utilities: ["consumer", "civil_code"],
    rent: ["civil_code"], banking_finance: ["banks", "civil_code"], traffic_transport: ["traffic", "admin_code"],
    notary_inheritance: ["notary", "civil_code"], migration_citizenship: ["citizenship"], pension_social: ["pension"],
    healthcare: ["health"], education: ["education"], business_tax: ["tax_code", "business"], ecology: ["nature"], other: ["local_gov"]
  };

  // Javob muddati (Murojaatlar toʻgʻrisidagi qonun boʻyicha umumiy qoida) — TEKSHIRILSIN
  const DEADLINE = {
    lawId: "appeals", standardDays: 15, extendedDays: 30, dayType: "calendar",
    verified: false, note: "15 kun (qoʻshimcha oʻrganish talab etilmasa) / 1 oygacha (talab etilsa). Kun turi va aniq modda lex.uz da tekshirilsin."
  };

  // Rus tilida "В соответствии с ..." iborasi uchun vositali kelishik shakli
  LAWS.appeals.inline = { ru: "Законом Республики Узбекистан «Об обращениях физических и юридических лиц»" };

  function forCategory(cat) { return (BY_CATEGORY[cat] || []).map(function (id) { return LAWS[id]; }); }

  return { LAWS: LAWS, BY_CATEGORY: BY_CATEGORY, DEADLINE: DEADLINE, forCategory: forCategory, appeals: LAWS.appeals };
})();
