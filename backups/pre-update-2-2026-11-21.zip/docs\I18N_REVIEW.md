# Tarjimalarni inson tomonidan tekshirish roʻyxati

## 1. Qoraqalpoq tili (`ҚҚ`, `kaa`) — **toʻliq tekshiruv SHART**
- Manba: `i18n-src/kaa.latn.json` (lotin). Undan `scripts/gen_i18n.py` orqali `js/i18n/kaa.js` (kirill) hosil qilinadi.
- Butun lugʻat (351 kalit) ona tili egasi tomonidan koʻrib chiqilmagan — `// REVIEW` belgisi fayl boshida turibdi.
- Alohida eʼtibor talab qiladigan joylar:
  - Lotin → kirill qoidalari (`á→ә`, `ó→ө`, `ú→ү`, `ń→ң`, `ǵ→ғ`, `ı→ы`, `w→ў`, soʻz boshidagi `I→И`) — ayniqsa `е/э` va katta harflar.
  - `Мәселенизди` kabi soʻzlarda `ң` / `н` farqi (manbada ayrim joylarda `n` yozilgan boʻlishi mumkin).
  - Rasmiy uslubdagi iboralar: `doc.*` (hujjat shabloni), `va.*` (tekshiruv), `r5.repeatText`.
  - Lavozimlarning joʻnalish kelishigi: `js/data/organizations_db.js` → `ROLE.*.to.kaa` (`Ҳәкимге`, `Басқарма баслығына`…).
  - Organ nomlari, qonun nomlari va mazmuni kaa uchun **oʻzbekchadan kirillga oʻgiriladi** (ular qoraqalpoqcha emas, oʻzbekcha).
  - Demo matnlari: `js/data/demos.js` → `kaa`.

## 2. Oʻzbek kirill (`ЎЗ`, `uz-Cyrl`)
- `js/i18n/uz-Cyrl.js` lotin lugʻatidan qoidaviy oʻgirish va qoʻlda tuzatishlar bilan hosil qilingan. Tekshirish tavsiya etiladi:
  - `е/э` (soʻz boshida `э`), `ъ` (`субъект`), qisqartmalar (`СИ` = sunʼiy intellekt, `МЧЖ`).
  - Rus tilidan oʻzlashgan soʻzlar (`инспекция`, `квитанция`, `компенсация`, `колл-марказ`) `POST_FIX` qoidalari bilan tuzatilgan — boshqa shunday soʻzlar qolmaganini tekshiring.
- Maʼlumotlar bazasi matnlari (organlar, qonunlar mazmuni, hudud nomlari) ish vaqtida `js/lib/translit.js` bilan oʻgiriladi (zaxira). Rasmiy kirill nomlari bilan solishtirish kerak.

## 3. Rus va ingliz tillari
- Qonun nomlarining rasmiy tarjimalarini lex.uz dagi rus/ingliz versiyalari bilan solishtiring (`js/data/legal_basis_db.js`).
- Hududiy organlar nomlarining ruscha shakli (`Хокимият (Асака район)`) qolip asosida tuzilgan — rasmiy nomlar bilan almashtiring.
- Tuman nomlarining ruscha shakli oʻzbekchadan oʻgirilgan (`Асака район`, `Чилонзор район`) — rasmiy ruscha nomlar (`Чиланзарский район`) bilan almashtirish tavsiya etiladi.

## 4. Glossariy
- `js/i18n/glossary.js` — `murojat` / `мурожат` / `обращение` / `мүрәжат` / `appeal`. Atama oʻzgarsa, faqat shu fayl va `scripts/gen_i18n.py` qayta ishga tushiriladi.
