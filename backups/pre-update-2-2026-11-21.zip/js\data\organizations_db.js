/* =====================================================================
   organizations_db — vakolatli organlar bazasi
   Yangi organ qoʻshish = ORGS roʻyxatiga bitta yozuv qoʻshish.
   Tuzilma (TypeScript koʻrinishida):
     { id, level: 'national'|'region'|'district', regionId?, districtId?,
       name: { 'uz-Latn': string, ru?, en?, 'uz-Cyrl'?, kaa? },
       address?, website?, phone?, responsibleRole?: {…til…},
       categories: CategoryId[], channels?: ['online','paper','reception'],
       sources: [{title,url}], verified: boolean, lastVerified?: 'YYYY-MM-DD' }

   ⚠ MUHIM: bu muhitda rasmiy manbalarni tekshirib boʻlmadi. Shu sababli
   barcha yozuvlar verified: false, manzil/telefon/sayt KIRITILMAGAN
   (uydirma maʼlumot qoʻshilmaydi). Hududiy yozuvlar umumiy nomlash qolipi
   asosida hosil qilingan — rasmiy nomi tekshirilishi kerak.
   Masʼul shaxslarning ism-sharifi kiritilmaydi — faqat lavozim.
   ===================================================================== */
window.EM_ORGS = (function () {
  "use strict";
  const REG = window.EM_REGIONS;
  const TR = window.EM_TRANSLIT;
  const TODO_SRC = [{ titleKey: "src.todo", title: "Rasmiy manba bilan tekshirilsin (my.gov.uz / organ sayti / lex.uz)", url: "https://my.gov.uz" }];

  // Lavozim nomi va hujjatdagi "Kimga" shakli (joʻnalish kelishigi). kaa — REVIEW.
  const ROLE = {
    hokim: { "uz-Latn": "Hokim", ru: "Хоким", en: "Khokim", kaa: "Ҳәким",
      to: { "uz-Latn": "Hokimga", ru: "Хокиму", en: "To the Khokim", kaa: "Ҳәкимге" } },
    head: { "uz-Latn": "Boshqarma boshligʻi", ru: "Начальник управления", en: "Head of department", kaa: "Басқарма баслығы",
      to: { "uz-Latn": "Boshqarma boshligʻiga", ru: "Начальнику управления", en: "To the Head of department", kaa: "Басқарма баслығына" } },
    deptHead: { "uz-Latn": "Boʻlim boshligʻi", ru: "Начальник отдела", en: "Head of division", kaa: "Бөлим баслығы",
      to: { "uz-Latn": "Boʻlim boshligʻiga", ru: "Начальнику отдела", en: "To the Head of division", kaa: "Бөлим баслығына" } },
    minister: { "uz-Latn": "Vazir", ru: "Министр", en: "Minister", kaa: "Министр",
      to: { "uz-Latn": "Vazirga", ru: "Министру", en: "To the Minister", kaa: "Министрге" } },
    chair: { "uz-Latn": "Rais", ru: "Председатель", en: "Chairman", kaa: "Баслық",
      to: { "uz-Latn": "Raisga", ru: "Председателю", en: "To the Chairman", kaa: "Баслыққа" } },
    director: { "uz-Latn": "Direktor", ru: "Директор", en: "Director", kaa: "Директор",
      to: { "uz-Latn": "Direktorga", ru: "Директору", en: "To the Director", kaa: "Директорға" } },
    governor: { "uz-Latn": "Markaziy bank raisi", ru: "Председатель Центрального банка", en: "Governor of the Central Bank", kaa: "Орайлық банк баслығы",
      to: { "uz-Latn": "Markaziy bank raisiga", ru: "Председателю Центрального банка", en: "To the Governor of the Central Bank", kaa: "Орайлық банк баслығына" } },
    judge: { "uz-Latn": "Sud raisi", ru: "Председатель суда", en: "Chair of the court", kaa: "Суд баслығы",
      to: { "uz-Latn": "Sud raisiga", ru: "Председателю суда", en: "To the Chair of the court", kaa: "Суд баслығына" } },
    ombudsman: { "uz-Latn": "Vakil", ru: "Уполномоченный", en: "Ombudsman", kaa: "Ўәкил",
      to: { "uz-Latn": "Vakilga", ru: "Уполномоченному", en: "To the Ombudsman", kaa: "Ўәкилге" } }
  };

  /* ---------- Respublika darajasi (har bir soha uchun zaxira) ---------- */
  const NATIONAL = [
    { id: "nat-labor", categories: ["labor"], role: "head",
      name: { "uz-Latn": "Davlat mehnat inspeksiyasi", ru: "Государственная инспекция труда", en: "State Labor Inspectorate" } },
    { id: "nat-consumer", categories: ["consumer"], role: "chair",
      name: { "uz-Latn": "Raqobatni rivojlantirish va isteʼmolchilar huquqlarini himoya qilish qoʻmitasi", ru: "Комитет по развитию конкуренции и защите прав потребителей", en: "Committee for the Development of Competition and Protection of Consumer Rights" } },
    { id: "nat-housing", categories: ["housing_utilities"], role: "minister",
      name: { "uz-Latn": "Qurilish va uy-joy kommunal xoʻjaligi vazirligi", ru: "Министерство строительства и жилищно-коммунального хозяйства", en: "Ministry of Construction and Housing and Communal Services" } },
    { id: "nat-rent", categories: ["rent"], role: "judge", channels: ["paper", "online"],
      name: { "uz-Latn": "Fuqarolik ishlari boʻyicha sud (yashash joyingiz boʻyicha)", ru: "Суд по гражданским делам (по месту жительства)", en: "Civil court (at your place of residence)" } },
    { id: "nat-banking", categories: ["banking_finance"], role: "governor",
      name: { "uz-Latn": "Oʻzbekiston Respublikasi Markaziy banki", ru: "Центральный банк Республики Узбекистан", en: "Central Bank of the Republic of Uzbekistan" } },
    { id: "nat-traffic", categories: ["traffic_transport"], role: "head",
      name: { "uz-Latn": "Ichki ishlar vazirligi Yoʻl harakati xavfsizligi xizmati", ru: "Служба безопасности дорожного движения МВД", en: "Road Traffic Safety Service of the Ministry of Internal Affairs" } },
    { id: "nat-notary", categories: ["notary_inheritance"], role: "minister",
      name: { "uz-Latn": "Oʻzbekiston Respublikasi Adliya vazirligi", ru: "Министерство юстиции Республики Узбекистан", en: "Ministry of Justice of the Republic of Uzbekistan" } },
    { id: "nat-migration", categories: ["migration_citizenship"], role: "head",
      name: { "uz-Latn": "Ichki ishlar vazirligi Migratsiya va fuqarolikni rasmiylashtirish xizmati", ru: "Служба миграции и оформления гражданства МВД", en: "Migration and Citizenship Service of the Ministry of Internal Affairs" } },
    { id: "nat-pension", categories: ["pension_social"], role: "director",
      name: { "uz-Latn": "Ijtimoiy himoya milliy agentligi", ru: "Национальное агентство социальной защиты", en: "National Agency for Social Protection" } },
    { id: "nat-health", categories: ["healthcare"], role: "minister",
      name: { "uz-Latn": "Oʻzbekiston Respublikasi Sogʻliqni saqlash vazirligi", ru: "Министерство здравоохранения Республики Узбекистан", en: "Ministry of Health of the Republic of Uzbekistan" } },
    { id: "nat-education", categories: ["education"], role: "minister",
      name: { "uz-Latn": "Maktabgacha va maktab taʼlimi vazirligi", ru: "Министерство дошкольного и школьного образования", en: "Ministry of Preschool and School Education" } },
    { id: "nat-tax", categories: ["business_tax"], role: "chair",
      name: { "uz-Latn": "Soliq qoʻmitasi", ru: "Налоговый комитет", en: "Tax Committee" } },
    { id: "nat-ecology", categories: ["ecology"], role: "minister",
      name: { "uz-Latn": "Ekologiya, atrof-muhitni muhofaza qilish va iqlim oʻzgarishi vazirligi", ru: "Министерство экологии, охраны окружающей среды и изменения климата", en: "Ministry of Ecology, Environmental Protection and Climate Change" } },
    { id: "nat-other", categories: ["other"], role: "director", channels: ["online", "paper", "reception"],
      name: { "uz-Latn": "Oʻzbekiston Respublikasi Prezidentining Virtual qabulxonasi (pm.gov.uz)", ru: "Виртуальная приёмная Президента Республики Узбекистан (pm.gov.uz)", en: "Virtual Reception of the President of Uzbekistan (pm.gov.uz)" },
      website: "https://pm.gov.uz" }
  ];

  /* ---------- Hududiy qoliplar (umumiy nomlash qolipi — tekshirilsin) ---------- */
  function regionName(r, loc) { return REG.label(r, loc); }
  function cyr(s) { return TR.uzLatnToCyrl(s); }

  // Viloyat darajasi: {R} — hudud nomi
  const REGION_TPL = [
    { cat: ["labor"], role: "head", key: "labor",
      uz: function (R) { return "Davlat mehnat inspeksiyasining " + R + " boshqarmasi"; },
      ru: function (R) { return "Управление Государственной инспекции труда (" + R + ")"; },
      en: function (R) { return "State Labor Inspectorate — " + R + " office"; } },
    { cat: ["consumer"], role: "head", key: "consumer",
      uz: function (R) { return "Raqobatni rivojlantirish va isteʼmolchilar huquqlarini himoya qilish qoʻmitasining " + R + " boshqarmasi"; },
      ru: function (R) { return "Территориальное управление Комитета по развитию конкуренции и защите прав потребителей (" + R + ")"; },
      en: function (R) { return "Consumer Protection Committee — " + R + " office"; } },
    { cat: ["pension_social"], role: "head", key: "pension",
      uz: function (R) { return "Ijtimoiy himoya milliy agentligining " + R + " boshqarmasi"; },
      ru: function (R) { return "Управление Национального агентства социальной защиты (" + R + ")"; },
      en: function (R) { return "National Agency for Social Protection — " + R + " office"; } },
    { cat: ["healthcare"], role: "head", key: "health",
      uz: function (R) { return R + " sogʻliqni saqlash boshqarmasi"; },
      ru: function (R) { return "Управление здравоохранения (" + R + ")"; },
      en: function (R) { return R + " health department"; } },
    { cat: ["notary_inheritance"], role: "head", key: "justice",
      uz: function (R) { return R + " adliya boshqarmasi"; },
      ru: function (R) { return "Управление юстиции (" + R + ")"; },
      en: function (R) { return R + " justice department"; } },
    { cat: ["traffic_transport"], role: "head", key: "traffic",
      uz: function (R) { return R + " ichki ishlar boshqarmasi Yoʻl harakati xavfsizligi boshqarmasi"; },
      ru: function (R) { return "Управление безопасности дорожного движения УВД (" + R + ")"; },
      en: function (R) { return R + " internal affairs — road traffic safety department"; } },
    { cat: ["migration_citizenship"], role: "head", key: "migration",
      uz: function (R) { return R + " ichki ishlar boshqarmasi Migratsiya va fuqarolikni rasmiylashtirish boshqarmasi"; },
      ru: function (R) { return "Управление миграции и оформления гражданства УВД (" + R + ")"; },
      en: function (R) { return R + " internal affairs — migration and citizenship department"; } },
    { cat: ["ecology"], role: "head", key: "ecology",
      uz: function (R) { return R + " ekologiya va atrof-muhitni muhofaza qilish boshqarmasi"; },
      ru: function (R) { return "Управление экологии и охраны окружающей среды (" + R + ")"; },
      en: function (R) { return R + " ecology and environmental protection department"; } },
    { cat: ["business_tax"], role: "head", key: "tax",
      uz: function (R) { return R + " soliq boshqarmasi"; },
      ru: function (R) { return "Налоговое управление (" + R + ")"; },
      en: function (R) { return R + " tax department"; } }
  ];

  // Tuman/shahar darajasi: {D} — tuman yoki shahar nomi ("Chilonzor tumani")
  const DISTRICT_TPL = [
    { cat: ["housing_utilities", "other"], role: "hokim", key: "hokimlik",
      uz: function (D) { return D + " hokimligi"; },
      ru: function (D) { return "Хокимият (" + D + ")"; },
      en: function (D) { return D + " khokimiyat"; } },
    { cat: ["pension_social"], role: "deptHead", key: "pension",
      uz: function (D) { return "Ijtimoiy himoya milliy agentligining " + D + " boʻlimi"; },
      ru: function (D) { return "Отдел Национального агентства социальной защиты (" + D + ")"; },
      en: function (D) { return "National Agency for Social Protection — " + D + " division"; } },
    { cat: ["education"], role: "deptHead", key: "education",
      uz: function (D) { return D + " maktabgacha va maktab taʼlimi boʻlimi"; },
      ru: function (D) { return "Отдел дошкольного и школьного образования (" + D + ")"; },
      en: function (D) { return D + " preschool and school education division"; } },
    { cat: ["business_tax"], role: "deptHead", key: "tax",
      uz: function (D) { return D + " davlat soliq inspeksiyasi"; },
      ru: function (D) { return "Государственная налоговая инспекция (" + D + ")"; },
      en: function (D) { return D + " state tax inspectorate"; } }
  ];

  function names(tpl, uzName, ruName, enName) {
    return { "uz-Latn": tpl.uz(uzName), ru: tpl.ru(ruName), en: tpl.en(enName) };
  }

  const ORGS = [];
  NATIONAL.forEach(function (o) {
    ORGS.push({ id: o.id, level: "national", name: o.name, website: o.website, responsibleRole: ROLE[o.role],
      categories: o.categories, channels: o.channels || ["online", "paper", "reception"], sources: TODO_SRC, verified: false });
  });
  REG.REGIONS.forEach(function (r) {
    REGION_TPL.forEach(function (tpl) {
      ORGS.push({ id: "reg-" + r.id + "-" + tpl.key, level: "region", regionId: r.id,
        name: names(tpl, r.name["uz-Latn"], r.name.ru, r.name.en), responsibleRole: ROLE[tpl.role],
        categories: tpl.cat, channels: ["online", "paper", "reception"], sources: TODO_SRC, verified: false, generated: true });
    });
    r.districts.forEach(function (d) {
      DISTRICT_TPL.forEach(function (tpl) {
        ORGS.push({ id: "dist-" + d.id + "-" + tpl.key, level: "district", regionId: r.id, districtId: d.id,
          name: names(tpl, d.name["uz-Latn"], REG.label(d, "ru"), d.name.en), responsibleRole: ROLE[tpl.role],
          categories: tpl.cat, channels: ["online", "paper", "reception"], sources: TODO_SRC, verified: false, generated: true });
      });
    });
  });

  /**
   * Soha va hudud boʻyicha organni topadi: tuman → viloyat → respublika.
   * @returns {{org, fallback: null|'region'|'national'}}
   */
  function resolve(categoryId, regionId, districtId) {
    const has = function (o) { return o.categories.indexOf(categoryId) >= 0; };
    const d = ORGS.find(function (o) { return o.level === "district" && o.districtId === districtId && has(o); });
    if (d) return { org: d, fallback: null };
    const r = ORGS.find(function (o) { return o.level === "region" && o.regionId === regionId && has(o); });
    if (r) return { org: r, fallback: districtId ? "region" : null };
    const n = ORGS.find(function (o) { return o.level === "national" && has(o); }) || ORGS.find(function (o) { return o.id === "nat-other"; });
    return { org: n, fallback: regionId ? "national" : null };
  }

  /** Organ nomi joriy tilda (kirill tillar uchun oʻzbekchadan oʻgiriladi) */
  function label(org, locale) {
    if (!org) return "";
    if (org.name[locale]) return org.name[locale];
    if (locale === "uz-Cyrl" || locale === "kaa") return cyr(org.name["uz-Latn"]);
    return org.name["uz-Latn"];
  }
  function role(org, locale) {
    const r = org && org.responsibleRole;
    if (!r) return "";
    if (r[locale]) return r[locale];
    return (locale === "uz-Cyrl" || locale === "kaa") ? cyr(r["uz-Latn"]) : r["uz-Latn"];
  }
  /** Hujjatdagi "Kimga" qatori uchun lavozim (joʻnalish kelishigida) */
  function roleTo(org, locale) {
    const r = org && org.responsibleRole && org.responsibleRole.to;
    if (!r) return "";
    if (r[locale]) return r[locale];
    return locale === "uz-Cyrl" ? cyr(r["uz-Latn"]) : r["uz-Latn"];
  }

  return { ORGS: ORGS, resolve: resolve, label: label, role: role, roleTo: roleTo, regionName: regionName };
})();
