/* =====================================================================
   E-murojat — unit testlar (brauzerda ishlaydi: tests/unit.html)
   Natija: window.__TEST_RESULTS = { passed, failed, failures[] }
   ===================================================================== */
(function () {
  "use strict";
  const results = { passed: 0, failed: 0, failures: [] };
  let group = "";
  function describe(name, fn) { group = name; fn(); }
  function eq(actual, expected, msg) {
    const ok = JSON.stringify(actual) === JSON.stringify(expected);
    if (ok) results.passed++;
    else { results.failed++; results.failures.push(group + " › " + (msg || "") + " — kutilgan: " + JSON.stringify(expected) + ", olingan: " + JSON.stringify(actual)); }
  }
  function ok(cond, msg) { eq(!!cond, true, msg); }

  const UZ = window.EM_UZ, TR = window.EM_TRANSLIT, V = window.EM_VALID;

  describe("uzNormalize", function () {
    ["'", "‘", "’", "ʻ", "ʼ", "`"].forEach(function (a) {
      eq(UZ.normalizeApostrophes("o" + a + "zbek"), "oʻzbek", "o + " + JSON.stringify(a));
      eq(UZ.normalizeApostrophes("g" + a + "isht"), "gʻisht", "g + " + JSON.stringify(a));
      eq(UZ.normalizeApostrophes("ma" + a + "lum"), "maʼlum", "tutuq + " + JSON.stringify(a));
    });
    eq(UZ.normalizeApostrophes("tog'"), "togʻ", "soʻz oxiridagi gʻ");
    eq(UZ.normalizeApostrophes("O'zbekiston"), "Oʻzbekiston", "bosh harf Oʻ");
    eq(UZ.normalizeApostrophes("e'tibor san'at"), "eʼtibor sanʼat", "bir nechta tutuq");
    eq(UZ.normalizeApostrophes("to'g'ri"), "toʻgʻri", "ketma-ket oʻ va gʻ");
    eq(UZ.normalizeApostrophes("'o'"), "'o'", "yakka o' (qoʻshtirnoq) oʻzgarmaydi");
    eq(UZ.normalizeSpacing("salom ,  dunyo  !"), "salom, dunyo!", "boʻshliq va tinish belgilari");
    eq(UZ.sentence("murojat matni"), "Murojat matni.", "gap shakli");
    eq(UZ.forMatch("Doʻkon"), "do'kon", "taqqoslash shakli");
  });

  describe("translit (lotin → kirill)", function () {
    const c = TR.uzLatnToCyrl;
    eq(c("shahar"), "шаҳар", "sh, h");
    eq(c("choy"), "чой", "ch, y");
    eq(c("oʻzbek"), "ўзбек", "oʻ va soʻz boshidagi o");
    eq(c("togʻ"), "тоғ", "gʻ");
    eq(c("tong"), "тонг", "ng");
    eq(c("ekin"), "экин", "soʻz boshidagi e → э");
    eq(c("telefon"), "телефон", "soʻz ichidagi e → е");
    eq(c("yer yoz yurt yana"), "ер ёз юрт яна", "ye/yo/yu/ya");
    eq(c("yoʻl"), "йўл", "yoʻ = й + ў");
    eq(c("xabar"), "хабар", "x → х");
    eq(c("qishloq"), "қишлоқ", "q → қ");
    eq(c("maʼlum"), "маълум", "tutuq → ъ");
    eq(c("Isʼhoq"), "Исҳоқ", "sʼh → сҳ");
    eq(c("ARIZA SHIKOYAT"), "АРИЗА ШИКОЯТ", "toʻliq katta harf");
    eq(c("Shahar"), "Шаҳар", "bosh harf Sh");
    eq(c("subyekt"), "субъект", "undosh + ye → ъе");
    eq(c("my.gov.uz va ism@pochta.uz"), "my.gov.uz ва ism@pochta.uz", "URL va e-pochta oʻgirilmaydi");
    eq(c("{fish} §m"), "{fish} §m", "oʻzgaruvchi va token oʻgirilmaydi");
    eq(c("ma'lum"), "маълум", "oddiy apostrof ham normallashadi");
  });

  describe("translit (kirill → lotin, qoraqalpoq)", function () {
    eq(TR.uzCyrlToLatn("Иш ҳақи"), "Ish haqi", "oʻzbek kirill → lotin");
    eq(TR.uzCyrlToLatn("ўзбек"), "oʻzbek", "ў → oʻ");
    eq(TR.kaaLatnToCyrl("Qaraqalpaqstan"), "Қарақалпақстан", "qoraqalpoq lotin → kirill");
    eq(TR.kaaLatnToCyrl("áwele"), "әўеле", "á, w");
    eq(TR.kaaCyrlToLatn("жумыс"), "jumıs", "qoraqalpoq kirill → lotin");
  });

  describe("telefon va e-pochta", function () {
    eq(V.formatPhone("901234567"), "+998 90 123 45 67", "maska");
    eq(V.formatPhone("+998901234567"), "+998 90 123 45 67", "998 bilan");
    ok(V.isValidPhone("+998 90 123 45 67"), "toʻgʻri raqam");
    ok(!V.isValidPhone("+998 90 123"), "qisqa raqam");
    ok(!V.isValidPhone(""), "boʻsh raqam");
    ok(!V.isValidPhone("+998 00 123 45 67"), "0 bilan boshlangan operator kodi");
    ok(V.isValidEmail("ism@pochta.uz"), "toʻgʻri e-pochta");
    ok(!V.isValidEmail("ism@pochta"), "domen yoʻq");
    ok(!V.isValidEmail("ism pochta.uz"), "@ yoʻq");
    ok(V.isValidFish("Aliyev Akmal"), "2 soʻz");
    ok(!V.isValidFish("Aliyev"), "1 soʻz");
    ok(V.isValidFish("Алиев Акмал"), "kirill F.I.Sh.");
    ok(V.isValidAddress("Navoiy koʻchasi, 5-uy"), "manzil raqam bilan");
    ok(!V.isValidAddress("Navoiy"), "raqamsiz manzil");
    const good = { fish: "Aliyev Akmal", regionId: "an", districtId: "an-asaka", address: "Navoiy 5", phone: "", email: "a@b.uz" };
    ok(V.validateProfile(good).ok, "toʻliq profil");
    eq(Object.keys(V.validateProfile(Object.assign({}, good, { email: "" })).errors), ["contact"], "aloqa yoʻq");
    eq(V.validateProfile(Object.assign({}, good, { phone: "+998 90" })).errors.phone, "err.phone", "notoʻgʻri telefon");
  });

  describe("validateAppeal", function () {
    const VA = window.EM_VALIDATE.validateAppeal;
    const profile = { fish: "Aliyev Akmal Karimovich", regionId: "an", districtId: "an-asaka", address: "Navoiy 5-uy", phone: "+998 90 123 45 67", email: "" };
    const analysis = { category: "labor", confidence: 0.8, documentType: "SHIKOYAT", requestedAction: "Ish haqini undirish", missingInfo: [] };
    const r1 = VA({ profile: profile, analysis: analysis, answers: {}, attachmentsCount: 2, text: "matn", history: [] });
    eq(r1.status, "green", "hammasi toʻliq → yashil");
    eq(r1.ok, r1.all, "barcha tekshiruvlar oʻtdi");
    const r2 = VA({ profile: Object.assign({}, profile, { fish: "Aliyev" }), analysis: analysis, answers: {}, attachmentsCount: 1, text: "matn", history: [] });
    eq(r2.status, "red", "F.I.Sh. chala → qizil");
    const r3 = VA({ profile: profile, analysis: Object.assign({}, analysis, { requestedAction: "" }), answers: { request: "Toʻlash" }, attachmentsCount: 1, text: "matn", history: [] });
    eq(r3.items.find(function (x) { return x.id === "request"; }).status, "pass", "talab aniqlashtirish javobidan olinadi");
    const r4 = VA({ profile: profile, analysis: analysis, answers: {}, attachmentsCount: 0, text: "matn", history: [] });
    eq(r4.status, "yellow", "ilova yoʻq → sariq");
    const h = window.EM_VALIDATE.textHash("matn");
    const r5 = VA({ profile: profile, analysis: analysis, answers: {}, attachmentsCount: 1, text: "matn", history: [{ hash: h, at: Date.now() - 3600 * 1000 }] });
    eq(r5.items.find(function (x) { return x.id === "duplicate"; }).status, "warn", "takroriy murojat aniqlanadi");
  });

  describe("lokal tasniflash (14 soha)", function () {
    const C = window.EM_AI.classifyLocal;
    eq(C("Ish joyimda 3 oydan beri maosh berishmayapti").category, "labor", "mehnat (lotin)");
    eq(C("Иш жойимда маош беришмаяпти, иш ҳақи йўқ").category, "labor", "mehnat (oʻzbek kirill)");
    eq(C("Уже 3 месяца не выплачивают зарплату").category, "labor", "mehnat (rus)");
    eq(C("My employer has not paid my salary").category, "labor", "mehnat (ingliz)");
    eq(C("Doʻkondan sotib olgan tovarim sifatsiz chiqdi").category, "consumer", "isteʼmolchi");
    eq(C("Uyimizda gaz yoʻq, svet ham oʻchib qoladi").category, "housing_utilities", "kommunal");
    eq(C("Ijaraga bergan uy egasi garov pulini qaytarmayapti").category, "rent", "ijara");
    eq(C("Bank kredit foizini oshirib yubordi").category, "banking_finance", "bank");
    eq(C("YHXX jarima yozdi, haydovchilik guvohnomasi").category, "traffic_transport", "yoʻl harakati");
    eq(C("Notarius meros hujjatini rasmiylashtirmayapti").category, "notary_inheritance", "notarius");
    eq(C("Pasport va fuqarolik masalasida migratsiya xizmati").category, "migration_citizenship", "migratsiya");
    eq(C("Pensiya va nafaqa toʻlanmayapti").category, "pension_social", "pensiya");
    eq(C("Poliklinikada shifokor qabul qilmadi").category, "healthcare", "sogʻliq");
    eq(C("Maktabda oʻqituvchi dars oʻtmayapti").category, "education", "taʼlim");
    eq(C("Soliq inspeksiyasi tadbirkor sifatida jarimaladi").category, "business_tax", "soliq");
    eq(C("Zavod tutuni havo ifloslanishiga sabab boʻlmoqda").category, "ecology", "ekologiya");
    eq(C("Salom, bir savolim bor edi").category, "other", "boshqa");
    eq(C("Maosh berilmayapti").documentType, "SHIKOYAT", "shikoyat turi");
    eq(C("Mahallaga bolalar maydonchasi qurish taklifi bor").documentType, "TAKLIF", "taklif turi");
    ok(C("Maosh berilmayapti").missingInfo.length > 0 && C("Maosh berilmayapti").missingInfo.length <= 3, "1–3 ta aniqlashtiruvchi savol");
  });

  describe("AI javob sxemasi", function () {
    const VC = window.EM_AI.validateClassification;
    const good = { category: "labor", secondaryCategories: [], documentType: "SHIKOYAT", summary: "x", keyFacts: [], requestedAction: "y", missingInfo: [], confidence: 0.7 };
    ok(VC(good).ok, "toʻgʻri javob");
    ok(!VC(Object.assign({}, good, { category: "hack" })).ok, "notoʻgʻri soha rad etiladi");
    ok(!VC(Object.assign({}, good, { missingInfo: ["a", "b", "c", "d"] })).ok, "3 tadan ortiq savol rad etiladi");
    ok(!VC(Object.assign({}, good, { confidence: 2 })).ok, "ishonch 0..1 dan tashqari");
    const red = window.EM_AI.redact("Men Aliyev Akmal, tel +998 90 123 45 67, a@b.uz", { fish: "Aliyev Akmal", address: "" });
    ok(red.indexOf("Aliyev") < 0 && red.indexOf("123 45 67") < 0 && red.indexOf("a@b.uz") < 0, "shaxsiy maʼlumotlar yashiriladi");
  });

  describe("i18n lugʻatlari", function () {
    const base = Object.keys(window.EM_LOCALES["uz-Latn"]);
    ["uz-Cyrl", "ru", "kaa", "en"].forEach(function (L) {
      const keys = Object.keys(window.EM_LOCALES[L]);
      eq(base.filter(function (k) { return keys.indexOf(k) < 0; }), [], L + ": yetishmayotgan kalitlar yoʻq");
    });
    const cyr = Object.values(window.EM_LOCALES["uz-Cyrl"]).join(" ").replace(/<[^>]+>|https?:\S+|[\w.-]*\.(uz|env)\b|\{\w+\}|§\w|DOCX|PDF|MB|LexHakaton|MVP|ism@pochta\.uz/g, "");
    eq((cyr.match(/[A-Za-z]{2,}/g) || []), [], "uz-Cyrl lugʻatida lotin soʻzlar qolmagan");
    ok(!/E-murojaat/i.test(JSON.stringify(window.EM_LOCALES)), "eski brend shakli lugʻatlarda yoʻq");
    eq(window.EM_CONFIG.BRAND_NAME, "E-murojat", "brend nomi yagona konstantada");
    ok(window.EM_I18N.t("meta.title").indexOf("E-murojat") === 0, "§B tokeni brend nomiga almashadi");
  });

  describe("hujjat shabloni (7 boʻlim)", function () {
    window.EM_I18N.setLocale("uz-Latn");
    const paras = window.EM_DOC.build({
      profile: { fish: "Aliyev Akmal Karimovich", regionId: "an", districtId: "an-asaka", address: "Navoiy 5-uy", phone: "+998 90 123 45 67", email: "" },
      analysis: { source: "local", category: "labor", summary: "maosh berilmayapti", keyFacts: [], requestedAction: "Undirib berish", missingInfo: [] },
      answers: { date: "3 oydan beri" }, attachments: ["chek.jpg"], org: window.EM_ORGS.resolve("labor", "an", "an-asaka").org, docType: "SHIKOYAT"
    });
    eq(Array.from(new Set(paras.map(function (p) { return p.section; }))), [1, 2, 3, 4, 5, 6, 7], "7 boʻlim tartibda");
    ok(paras.some(function (p) { return /1-ilova: chek\.jpg/.test(p.html); }), "ilova raqamlangan");
    ok(paras.some(function (p) { return /SHIKOYAT/.test(p.html); }), "hujjat turi sarlavhasi");
  });

  describe("organlar bazasi (fallback)", function () {
    const O = window.EM_ORGS;
    eq(O.resolve("housing_utilities", "an", "an-asaka").org.level, "district", "tuman darajasi");
    eq(O.resolve("labor", "an", "an-asaka").fallback, "region", "tuman yoʻq → viloyat");
    eq(O.resolve("banking_finance", "an", "an-asaka").fallback, "national", "hudud yoʻq → respublika");
    ok(O.ORGS.every(function (o) { return o.name["uz-Latn"] && Array.isArray(o.sources) && typeof o.verified === "boolean"; }), "har bir yozuvda nom, manba va verified bor");
    ok(window.EM_REGIONS.REGIONS.length === 14, "14 ta hudud");
  });

  window.__TEST_RESULTS = results;
  const out = document.getElementById("out");
  if (out) {
    out.innerHTML = "<h1>" + (results.failed ? "❌" : "✅") + " " + results.passed + " oʻtdi, " + results.failed + " xato</h1>" +
      (results.failures.length ? "<ul>" + results.failures.map(function (f) { return "<li>" + window.EM_DOC.esc(f) + "</li>"; }).join("") + "</ul>" : "");
  }
})();
