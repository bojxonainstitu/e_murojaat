# Qabul qilingan qarorlar (E-murojat yangilanishi)

| # | Qaror | Sabab |
|---|---|---|
| 1 | **Stek oʻzgarmadi:** build'siz vanilla JS + kichik Python server. TypeScript, zod, npm, Vite qoʻshilmadi | Muhitda Node/npm yoʻq. Loyiha shu stekda ishlab turgan edi, uni noldan qayta yozish taqiqlangan |
| 2 | `typecheck`, `lint`, `build` **oʻrniga**: Python `py_compile`, brauzer unit testlari (`tests/unit.html`, 112+ tekshiruv), Python testlari (`server/test_server.py`), Playwright e2e (`tests/e2e.py`) | Build bosqichi yoʻq. Sintaksis xatolari unit/e2e testlarida sahifa yuklanganda aniqlanadi |
| 3 | **zod oʻrniga:** serverda `pydantic` (u `anthropic` SDK bilan birga oʻrnatiladi), brauzerda `validateClassification()` | npm yoʻq; ikki qatlamli tekshiruv saqlandi |
| 4 | **Git yoʻq** → `feature/e-murojat-update` branch va bosqichma-bosqich commit qilinmadi. Oʻrniga `backups/pre-update-2026-11-20.zip` (oʻzgarishlardan oldingi holat) va `backups/legacy-js/` (eski `ai.js`, `i18n.js`, `knowledge*.js`) | Muhit cheklovi |
| 5 | **AI kaliti brauzerdan olib tashlandi.** Eski "AI sozlamalari" oynasi (kalitni localStorage ga yozish) oʻrniga "AI va maxfiylik" oynasi; kalit faqat `.env` da | Xavfsizlik talabi eski funksiyadan ustun |
| 6 | **AI provayderi:** Anthropic Claude (`claude-opus-5-5`, rasmiy Python SDK), `output_config.format` (JSON sxema), `effort: low`, `fallbacks: "default"`. Boshqa provayder `server/ai_provider.py` da qoʻshiladi | Mavjud integratsiya Claude edi |
| 7 | AIga **faqat muammo matni** ketadi; F.I.Sh., manzil, telefon, e-pochta va ularga oʻxshash qismlar `redact()` bilan yashiriladi. Fayllar yuborilmaydi | Maxfiylik talabi |
| 8 | Foydalanuvchi matni `<appeal_text>` ichida **maʼlumot** sifatida beriladi; model javobi sxema bilan tekshiriladi va faqat `textContent`/ekranlangan holda chiqariladi | Prompt injection va XSS himoyasi |
| 9 | **Glossariy:** `murojat` atamasi `js/i18n/glossary.js` da (`§m/§M` tokenlari), brend `EM_CONFIG.BRAND_NAME`. **Qonunlarning rasmiy nomi** ("…murojaatlari toʻgʻrisida") **oʻzgartirilmadi** | Topshiriq "murojat" shaklini talab qiladi. Adabiy lugʻatdagi shakl "murojaat", rasmiy hujjat nomlari esa aynan keltirilishi shart. Atamani qaytarish kerak boʻlsa — faqat `glossary.js` ni oʻzgartirish kifoya |
| 10 | Apostrof toʻplami: `oʻ/gʻ` → U+02BB, tutuq → U+02BC (`js/lib/uzNormalize.js`) | Topshiriq tavsiyasi |
| 11 | **`uz-Cyrl.js` va `kaa.js`** statik fayllar. `scripts/gen_i18n.py` qoidaviy oʻgirish bilan hosil qiladi, soʻng qoʻlda koʻrib chiqilgan tuzatishlar (`OVERRIDES`, `POST_FIX`) qoʻllanadi. Qoraqalpoq manba matni: `i18n-src/kaa.latn.json` | Statik lugʻat koʻrib chiqiladigan artefakt. Ona tili egasi tekshiruvi shart (`I18N_REVIEW.md`) |
| 12 | Qoraqalpoq — **kirill** yozuvida (`ҚҚ`). Organ nomlari va maʼlumotlar bazasi matnlari kaa uchun oʻzbekcha nomdan kirillga oʻgiriladi (zaxira) | Barcha organlar uchun qoraqalpoqcha rasmiy nomlar yoʻq |
| 13 | **Organlar bazasi:** barcha yozuvlar `verified: false`. Manzil, telefon va sayt kiritilmadi (pm.gov.uz dan tashqari). Hududiy yozuvlar umumiy nomlash qolipidan hosil qilingan | Rasmiy manbani bu muhitda tekshirib boʻlmadi; uydirma taqiqlangan |
| 14 | **Qonun moddalari** `articles: []` — "modda raqami tekshirilsin". Javob muddati (15 kun / 30 kungacha, kalendar kuni) `verified: false` | Xuddi shu sabab |
| 15 | **Hududlar roʻyxati** (`regions.js`) xotiradan tuzilgan, `verified: false` | Rasmiy roʻyxat bilan solishtirish kerak |
| 16 | **STT:** `server/stt.py` da stub. `STT_DEMO_TEXT` berilsa, namoyish uchun shu matn qaytadi; aks holda 501 → "matnni yozing" | Haqiqiy provayder va kalit yoʻq |
| 17 | **Video:** `EM_CONFIG.VIDEO[locale].src = null` → "Video tez orada qoʻshiladi" + 3 qadamli yoʻriqnoma | Video manbasi berilmagan |
| 18 | **Cheklovlar** (`config.js`): fayl 10 MB, 10 ta fayl, jami 50 MB; ovoz 120 soniya; matn 20–6000 belgi; API 20 soʻrov/daqiqa (tasniflash), 10 soʻrov/daqiqa (STT) | Oqilona standart qiymatlar |
| 19 | **Qoralama** (profil + matn) foydalanuvchi qurilmasida localStorage da saqlanadi va "Maʼlumotlarimni oʻchirish" tugmasi bilan oʻchiriladi. Fayllar saqlanmaydi | Orqaga qaytganda va sahifa yangilanganda maʼlumot yoʻqolmasligi uchun |
| 20 | **Aniqlashtiruvchi savollar** lokal rejimda soha uchun muhim faktlar (sana, summa, abonent raqami…) va talab yoʻqligiga qarab beriladi (koʻpi bilan 3 ta) | `missingInfo` talabi AIsiz ham bajarilishi uchun |
| 21 | **Demo tugmalari** saqlandi. Ular profil va matnni toʻldirib, toʻgʻridan-toʻgʻri natijani koʻrsatadi ("Chala maʼlumot" — rad etilish tekshiruvini namoyish qiladi) | Eski funksiya saqlanishi talabi |
| 22 | **Shriftlar:** tizim shriftlari (Segoe UI / system-ui, hujjatda Times New Roman). Ular ў, қ, ғ, ҳ, ә, ң, ө, ү harflarini qamraydi — skrinshotlarda tekshirildi | Internetsiz ishlash; tashqi shrift yuklanmaydi |
| 23 | Kutubxonalar: yangi kutubxona qoʻshilmadi (brauzerda `docx@8.5.0` avvaldan bor). Serverda `anthropic` va `pydantic` (`server/requirements.txt`) | Minimal bogʻliqlik |
