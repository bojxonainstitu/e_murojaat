# E-murojaat — rasmiy murojaat tayyorlash yordamchisi (LexHakaton MVP)

Fuqaro oddiy so'zlar bilan muammosini yozadi. Sayt:

1. **qaysi organga** murojaat qilishni (asosiy va yuqori turuvchi organlar bilan),
2. **qanday shaklda** topshirishni (ariza / shikoyat / taklif, elektron yoki yozma, ilovalar),
3. **qaysi qonunchilikka** asoslanishni ko'rsatadi va **qaytarilish xavfini** (yashil / sariq / qizil) tekshiradi,
4. barcha rekvizitlari joyida bo'lgan **tayyor rasmiy hujjat** beradi. Hujjatni saytning o'zida tahrirlash, nusxalash, **DOCX** qilib yuklab olish va **chop etish / PDF** qilib saqlash mumkin.

## Titul varaq va tillar
- Sayt ochilganda **titul varaq** chiqadi va motion effektlar bilan yig'iladi. **"Murojaat qilish"** tugmasi ishchi oynani ochadi, **"Namunani ko'rish"** esa demoni yuklaydi. Logotip yoki "Bosh sahifa" tugmasi titul varaqqa qaytaradi.
- Ishchi oynani to'g'ridan-to'g'ri ochish uchun manzil oxiriga `#murojaat` qo'shing (masalan, `index.html#murojaat`).
- 4 til mavjud: **O'zbekcha** (yangi lotin imlosi: oʻ, gʻ, ʼ), **Русский**, **Qaraqalpaqsha**, **English**. Tilni yuqori o'ng burchakdagi tugmalar orqali tanlaysiz. Tanlangan til brauzerda eslab qolinadi, tayyor hujjat ham shu tilda tuziladi.
- Tarjimalar `js/i18n.js` (interfeys) va `js/knowledge.i18n.js` (huquqiy ma'lumotlar) fayllarida saqlanadi.

## Saytni ochish

### 1-usul: to'g'ridan-to'g'ri (internetsiz ham ishlaydi)
`index.html` faylini ikki marta bosib, Chrome, Edge yoki Firefox'da oching.
DOCX kutubxonasi `vendor/docx.umd.js` ichida lokal saqlangan, shuning uchun internet kerak emas.

### 2-usul: lokal server orqali (taqdimot uchun tavsiya etiladi)
```bash
python -m http.server 8765
```
So'ng brauzerda `http://localhost:8765` manzilini oching.

## Hakaton namoyishi (demo ssenariy)
| Tugma | Nimani ko'rsatadi |
|---|---|
| 💼 Ish haqi kechikishi | Mehnat inspeksiyasi, Mehnat kodeksi, to'liq hujjat (yashil holat) |
| 🛒 Sifatsiz tovar | Iste'molchilar huquqlarini himoya qilish organi, avval sotuvchiga talabnoma berish bosqichi |
| ⚠ Chala ma'lumot / Xavf testi | Manzil, aloqa va talab yo'q: qizil holat, nega qaytarilishi va nimani to'ldirish kerakligi |

Demo tugmasi formani to'ldiradi, tahlil qiladi va hujjatni bir yo'la tayyorlaydi.

## Fayl tuzilmasi
```
index.html          — titul varaq + ishchi oyna (header, 2 ustun, 4 kartochka, footer)
css/style.css       — dizayn + @media print (faqat hujjatning o'zi chop etiladi)
css/landing.css     — titul varaq dizayni va motion animatsiyalari
assets/             — logotip (logo-mark.png, logo-full.png) va namuna rasm
js/i18n.js          — 4 tilli interfeys tarjimalari, demo ma'lumotlar, til almashtirish
js/knowledge.js     — huquqiy bilimlar bazasi: toifalar, organlar, qonun nomlari, tekshiruvlar
js/knowledge.i18n.js — bilimlar bazasining ru / kaa / en tarjimasi
js/ai.js            — REAL AI API ULASH JOYI
js/app.js           — tahlil, qaytarilish xavfi, hujjat shakllantirish, DOCX / nusxa / chop etish
vendor/docx.umd.js  — docx@8.5.0 kutubxonasi (lokal; yuklanmasa CDN'ga o'tadi)
```

## Real AI API'ni ulash

Kalitsiz sayt **lokal (demo) mantiq** bilan to'liq ishlaydi: kalit so'zlar orqali toifa aniqlanadi, bilimlar bazasidan organ va qonun olinadi.

AI ulanganda u organni aniqlaydi, qonunlarni tanlaydi, muammoni rasmiy uslubda bayon qiladi va talablarni shakllantiradi. **Qaytarilish xavfi tekshiruvi esa har doim deterministik qoidalar bilan ishlaydi**, shuning uchun natija ishonchli va takrorlanadigan bo'ladi.

**Tezkor yo'l (namoyish uchun):** saytdagi **"⚙ AI sozlamalari"** tugmasini bosing va Anthropic (Claude) API kalitini kiriting. Kalit faqat shu brauzerning `localStorage` xotirasida saqlanadi.

**Kod orqali:** `js/ai.js` faylidagi `AI_CONFIG` obyekti:
```js
const AI_CONFIG = {
  endpoint: "https://api.anthropic.com/v1/messages", // yoki o'z proxy serveringiz
  model: "claude-opus-5-5",
  apiVersion: "2023-06-01",
  apiKey: "",
  timeoutMs: 90000
};
```
- So'rov `analyze(form)` funksiyasida yuboriladi. Model faqat JSON qaytaradi (sxema `SYSTEM_PROMPT` ichida yozilgan).
- Model rad etsa (`stop_reason: "refusal"`), server tomondagi `fallbacks: "default"` zaxira modelga o'tadi.
- Xato, timeout yoki JSON buzilgan bo'lsa, sayt avtomatik ravishda lokal mantiqqa qaytadi va bu haqda xabar chiqaradi.
- Xavfsizlik chorasi: AI javobidagi modda, band va qism raqamlari `stripArticleNumbers()` orqali olib tashlanadi.
- Boshqa AI provayderni ulash uchun faqat `analyze()` funksiyasini o'zgartiring. U quyidagi maydonlarga ega obyekt qaytarishi kerak: `turi, organ, kimga, sabab, qoshimcha[], bosqich[], qonunlar[{nom, mazmun}], bayon, talablar[]`.

> ⚠ **Ishlab chiqarishda API kalitini brauzerda saqlamang.** Kichik backend (proxy) yozing: u kalitni server tomonida qo'shsin. Keyin `AI_CONFIG.endpoint` ni o'sha proxy manziliga almashtiring va `x-api-key` sarlavhasini olib tashlang.

## Huquqiy ogohlantirish
- Qonun moddalari raqamlari **ataylab keltirilmagan**. Faqat qonun nomlari va umumiy huquqiy mazmun ishlatilgan:
  - Jismoniy va yuridik shaxslarning murojaatlari to'g'risidagi Qonun
  - Iste'molchilarning huquqlarini himoya qilish to'g'risidagi Qonun
  - Mehnat kodeksi va Fuqarolik kodeksi
  - Ta'lim to'g'risidagi Qonun, Fuqarolar sog'lig'ini saqlash to'g'risidagi Qonun, Mahalliy davlat hokimiyati to'g'risidagi Qonun va boshqalar
- Qonunlarning amaldagi tahriri va organlarning aniq nomini **[lex.uz](https://lex.uz)** hamda organlarning rasmiy saytlarida tekshiring. Davlat organlari tuzilmasi o'zgarib turishi mumkin.
- Hujjat loyihasi yordamchi vosita bilan tuzilgan. Yuborishdan oldin uni shaxsan tekshirib chiqing.
