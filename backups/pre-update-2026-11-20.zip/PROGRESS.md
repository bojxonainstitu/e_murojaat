# PROGRESS — E-murojaat (LexHakaton MVP)

> **Qoida:** har bir muhim qadamdan keyin shu fayl yangilanadi. Yangi sessiyada ishni boshlashdan oldin avval shu faylni va mavjud fayllarni o'qing. Mavjud kodni qaytadan yozmang, faqat kerakli joyini tahrirlang.

**Oxirgi yangilanish:** 2026-11-20 (2-bosqich: titul varaq + 4 til)

---

## ✅ Tayyor

| Fayl | Holati | Izoh |
|---|---|---|
| `index.html` | Tayyor | **Titul varaq** (`#landing`: logo, til almashtirgich, katta sarlavha, "Murojaat qilish" tugmasi, "Namunani koʻrish", 3 ta afzallik, girih fon, SVG ravoq kompozitsiyasi) + **ishchi oyna** (`#appShell`, boshida `hidden`): header (logo = bosh sahifa tugmasi, til almashtirgich, AI holati, demolar), 2 ustun, footer. Matnlar `data-i18n*` atributlari orqali. Skriptlar tartibi: `vendor/docx.umd.js` (yuklanmasa CDN) → `i18n.js` → `knowledge.js` → `knowledge.i18n.js` → `ai.js` → `app.js` |
| `css/style.css` | Tayyor | LegalTech dizayni: och fon, indigo rang, yashil / sariq / qizil holatlar. 1024px dan kengda 2 ustun, mobilda 1 ustun. `@media print` faqat `#docPaper` ni A4 formatda chiqaradi |
| `css/landing.css` | Tayyor | Titul varaq uslubi (logodagi ranglar: navy / indigo / teal / oltin) va **motion**: girih fonning paydo boʻlishi, diagonal panellar kirib kelishi, ravoqlarning "chizilishi" (stroke-dash), eshik koʻtarilishi, yulduz aylanishi, logo "pop", sarlavha harflari ketma-ket, CTA tugmasida yaltirash va toʻlqin halqa, sichqoncha bilan parallaks. Ilovaga oʻtish: "darvozadan kirish" (ravoq kattalashib yoʻqoladi). `prefers-reduced-motion` hurmat qilinadi |
| `js/i18n.js` | Tayyor | `window.EM_I18N`: 4 til — **uz** (yangi imlo: oʻ, gʻ, ʼ), **ru**, **kaa** (qoraqalpoq lotin), **en**. Interfeys, ogohlantirishlar (`w.<id>.t/f`), hujjat shabloni (`doc.*`), har til uchun demo maʼlumotlar. `t()`, `apply()`, `setLang()` (localStorage), `fixUz()` (oʻzbekcha matnda `o'`→`oʻ`, `'`→`ʼ`). Til almashganda `em:langchange` hodisasi chiqadi |
| `js/knowledge.i18n.js` | Tayyor | `window.EM_KB_I18N`: bilimlar bazasining ru/en/kaa tarjimasi (organ, kimga, sabab, bosqichlar, qonun nomlari va mazmuni, mavzu, standart talab, murojaat turlari, dalillar) + ruscha/inglizcha/qoraqalpoqcha kalit soʻzlar (toifa va turni aniqlash uchun) |
| `assets/` | Tayyor | `logo-full.png` (foydalanuvchi bergan logo), `logo-mark.png` (kesilgan belgi, foni shaffof), `hero-reference.png` (titul varaq uchun namuna rasm) |
| `js/knowledge.js` | Tayyor | `window.EM_KB`: Murojaatlar to'g'risidagi Qonun, 3 ta murojaat turi va ularni aniqlash so'zlari, 4 ta dalil turi. 8 ta toifa: mehnat, iste'molchi, kommunal, ta'lim, sog'liq, pensiya, korrupsiya, obodonlashtirish + `UMUMIY`. Har bir toifada organ, kimga, sabab, qo'shimcha organlar, bosqichlar, qonunlar, dalillar, mavzu, standart talab va `tekshir()` funksiyasi bor |
| `js/ai.js` | Kod tayyor, **real kalit bilan sinalmagan** | `window.EM_AI`: `AI_CONFIG` (endpoint, model `claude-opus-5-5`), kalitni olish/saqlash (`getKey`/`setKey`, localStorage), `analyze(form)`: Claude Messages API'ga so'rov yuboradi, javobdan JSON ajratadi, rad etish (`refusal`) va timeout holatlarini ushlaydi |
| `js/app.js` | Tayyor | Formani o'qish, 3 ta demo, lokal tahlil (toifa va tur aniqlash), to'liqlik / qaytarilish xavfi tekshiruvi (ball 0–100, holat; ogohlantirishlar `id` bilan), AI natijasini birlashtirish (`mergeAI` → `a.ai`, `view()` orqali joriy tilda chiziladi), 3 ta kartochka, tahrirlanadigan hujjat, nusxa / DOCX / chop etish. Yangi: `locCat/locTur/locDalil/locMQ` (bilimlar bazasini tilga moslash), titul varaq boshqaruvi (`enterApp`, `goHome`, `replayLanding`, harflarni boʻlish, parallaks), `#murojaat` xeshi bilan toʻgʻridan-toʻgʻri ilovaga kirish |
| `vendor/docx.umd.js` | Tayyor | docx@8.5.0, jsdelivr'dan yuklangan, global nomi `window.docx` |
| `README.md` | Tayyor | Saytni ochish, demo ssenariy, fayl tuzilmasi, AI'ni ulash, huquqiy ogohlantirish |
| `.claude/launch.json` | Tayyor | Brauzerda ko'rish uchun server: `python -m http.server 8765` |

### Brauzerda tekshirilgan (localhost:8765)
- 3 ta demo: ish haqi → yashil 100/100, sifatsiz tovar → yashil 100/100, chala ma'lumot → qizil 0/100 (3 ta qizil va 6 ta sariq ogohlantirish).
- "Tahlil qilish" va "Murojaatni tayyorlab ber" ishlaydi.
- DOCX: haqiqiy `.docx` fayl chiqadi (PK imzosi, to'g'ri MIME turi, ~8,7 KB).
- "Chop etish / PDF" tugmasi `window.print()` ni chaqiradi.
- Konsolda xato yo'q.

### Brauzerda tekshirilgan (2-bosqich: titul varaq + 4 til)
- Titul varaq 1440px va 375px (mobil) kenglikda chiroyli chiqadi, animatsiyalar ishlaydi, konsolda xato yoʻq.
- "Murojaat qilish" → oʻtish animatsiyasi → ishchi oyna (`#murojaat`). "Bosh sahifa" → titul varaq animatsiyasi qayta oʻynaydi.
- 4 tilda (uz/ru/kaa/en) × 3 demo: organ, xavf holati, hujjat sarlavhasi toʻgʻri; tarjima qilinmagan kalit yoki `undefined` yoʻq; oʻzbekcha hujjatda eski `o'`/`g'` qolmagan.
- Ruscha DOCX yuklandi (~9 KB).

## ⚠ Ishlamayapti / chala / tekshirilmagan
- **Qoraqalpoq tarjimasi** eng yaxshi urinish asosida yozilgan — ona tilida soʻzlashuvchi tekshirishi kerak. Ruscha va inglizcha ham huquqshunos koʻzidan oʻtishi tavsiya etiladi.
- **Til almashtirilganda** tayyor hujjat yangi tilda qayta tuziladi, ya'ni qoʻlda kiritilgan tahrirlar yoʻqoladi.
- **AI rejimida** javob soʻralgan paytdagi tilda keladi; keyin til almashtirilsa, AI matni oʻsha tilda qoladi (bilimlar bazasi qismi esa tarjima qilinadi).
- `knowledge.js` ichidagi asl oʻzbekcha matnlarda hali `o'` yozuvi turibdi — ekranga chiqishda `fixUz()` orqali `oʻ` ga aylantiriladi (qasddan: kalit soʻzlar bilan solishtirish oson boʻlishi uchun).
- **AI rejimi real API kaliti bilan sinalmagan.** CORS, `fallbacks` parametri va beta sarlavhasi jonli so'rovda tekshirilmagan.
- **Chop etish ko'rinishi** (print preview) ekranda tekshirilmagan. Faqat CSS qoidasi bor va print chaqirilishi tasdiqlangan.
- **DOCX ichidagi matn** Word'da ochib ko'rilmagan. Faqat fayl turi tekshirilgan.
- `file://` orqali ochilganda Claude brauzer paneli sahifani `data:` nusxa ko'rinishida ochadi. Oddiy Chrome yoki Edge'da `file://` ishlashi kerak, lekin alohida tekshirilmagan.
- **Toifa aniqlash oddiy kalit so'z bo'yicha ishlaydi.** Ko'p ma'noli so'zlar (masalan "tok", "yo'l") noto'g'ri toifaga olib borishi mumkin.
- **Organ nomlari:** kommunal, pensiya va ijtimoiy ta'minot organlarining aniq nomlari rasmiy manbalardan tekshirilmagan (UI'da "tekshiring" degan izoh bor).
- **F.I.Sh. tekshiruvi:** bitta so'zdan iborat F.I.Sh. hozircha faqat sariq ogohlantirish beradi.

## ➡ Keyingi qadamlar
1. Real API kaliti bilan AI rejimini sinash. Kerak bo'lsa `ai.js` dagi sarlavhalarni yoki `fallbacks` ni to'g'rilash.
2. Yuklangan DOCX'ni Word'da ochib tekshirish, chop etish ko'rinishini ko'rib chiqish.
3. Ishlab chiqarish uchun kichik server (proxy) qo'shish va kalitni brauzerdan olib tashlash.
4. Organ nomlarini rasmiy saytlar bo'yicha aniqlashtirish va kalit so'zlar ro'yxatini kengaytirish.
5. Ixtiyoriy: hududni (viloyat / tuman) tanlash maydoni, aniqroq organ manzili.
6. Qoraqalpoq, rus va ingliz tarjimalarini ona tilida soʻzlashuvchi / huquqshunos bilan tekshirish.
7. Ixtiyoriy: hujjat tilini interfeys tilidan alohida tanlash imkoniyati.

## 📌 Qabul qilingan muhim qarorlar
- **Modda raqamlari yozilmaydi.** Faqat qonun nomlari va umumiy mazmun ishlatiladi. AI javobidagi raqamlar `stripArticleNumbers()` orqali tozalanadi. Foydalanuvchiga lex.uz'da tekshirish eslatiladi.
- **Internetsiz ishlash:** Tailwind ishlatilmagan, oddiy CSS. docx kutubxonasi lokal yuklangan, CDN faqat zaxira.
- **Kod bo'limlarga ajratilgan:** index.html + css + 3 ta js fayl. Build va npm yo'q, `<script>` orqali global obyektlar (`EM_KB`, `EM_AI`).
- **Qaytarilish xavfi har doim qat'iy qoidalar bilan baholanadi**, AI ulangan bo'lsa ham. AI faqat organ, qonunlar, matn bayoni va talablarni beradi.
- **Hujjat rekvizitlari har doim shablondan qo'yiladi** (kimga, kimdan, manzil, aloqa, sarlavha, talablar, ilovalar, sana, imzo). Yetishmaydigan maydon qizil `[...]` bilan belgilanadi.
- **AI:** Claude, model `claude-opus-5-5`, effort `low`, `fallbacks: "default"`. Xato bo'lsa lokal mantiqqa qaytadi. Kalit localStorage'da saqlanadi, bu faqat demo uchun.
- **Murojaat turi avtomatik aniqlanadi:** huquq buzilishi so'zlari → shikoyat, taklif so'zlari → taklif, qolgan hollarda → ariza.
- **Hujjat matni** bevosita sahifada tahrirlanadi (`contenteditable`). DOCX va nusxa olish tahrirlangan matndan olinadi.
- **Titul varaq rasmi** fayl sifatida emas, SVG va CSS orqali qayta chizilgan (har qanday ekranga moslashadi, animatsiya qilinadi). Logo sifatida foydalanuvchi bergan rasm ishlatiladi (`assets/logo-mark.png`).
- **Koʻp tillilik:** interfeys va hujjat bir tilda chiqadi (tanlangan til). Toifani aniqlash barcha tillardagi kalit soʻzlar bilan ishlaydi. Oʻzbek tilida rasmiy lotin imlosi: `oʻ`, `gʻ` (U+02BB), tutuq belgisi `ʼ` (U+02BC).
- **Bosh sahifa / ilova** bitta `index.html` ichida: alohida sahifa yoʻq, `#murojaat` xeshi ilovani toʻgʻridan-toʻgʻri ochadi.

## 🕒 Jurnal
- **2026-11-20** — MVP to'liq yaratildi (barcha fayllar), brauzerda tekshirildi. Kichik tuzatishlar: hujjatda organ nomi takrorlanmaydigan qilindi, mavzu matnlaridagi qavslar olib tashlandi, "may" so'zi "kelmayapti" ichida xato topilishi tuzatildi, takroriy ogohlantirishlar olib tashlandi. README.md va PROGRESS.md yozildi.
- **2026-11-20 (2)** — Foydalanuvchi bergan rasm va logo asosida motion effektli titul varaq qoʻshildi ("Murojaat qilish" → ishchi oyna). Sayt 4 tilga oʻtkazildi (uz yangi imlo, ru, kaa, en): `js/i18n.js`, `js/knowledge.i18n.js`, `css/landing.css`, `assets/` qoʻshildi; `index.html`, `app.js`, `ai.js`, `knowledge.js` ga nuqtali oʻzgartirishlar kiritildi. Brauzerda tekshirildi.
