/* =====================================================================
   E-murojaat — ASOSIY MANTIQ
   Bo'limlar: 1) yordamchilar  2) demo ma'lumotlar  3) tahlil (lokal)
              4) AI natijasini birlashtirish  5) kartochkalarni chizish
              6) hujjat shakllantirish  7) nusxa / DOCX / chop etish
              8) hodisalar
   ===================================================================== */
(function () {
  "use strict";
  const KB = window.EM_KB;
  const AI = window.EM_AI;
  const I18N = window.EM_I18N;
  const KBI = window.EM_KB_I18N;
  const T = I18N.t;
  const $ = function (id) { return document.getElementById(id); };

  /* ---------- 0) TILGA MOSLASH (bilimlar bazasini joriy tilda olish) ---------- */
  function uzs(s) { return I18N.lang === "uz" ? I18N.fixUz(s) : s; }
  function overlay() { return I18N.lang === "uz" ? null : KBI.L[I18N.lang]; }
  function locCat(cat) {
    const o = overlay();
    if (o && o.cats[cat.id]) {
      return Object.assign({}, cat, o.cats[cat.id]);
    }
    return Object.assign({}, cat, {
      nom: uzs(cat.nom), organ: uzs(cat.organ), kimga: uzs(cat.kimga), sabab: uzs(cat.sabab),
      qoshimcha: cat.qoshimcha.map(uzs), bosqich: cat.bosqich.map(uzs),
      qonunlar: cat.qonunlar.map(function (q) { return { nom: uzs(q.nom), mazmun: uzs(q.mazmun) }; }),
      mavzu: uzs(cat.mavzu), standartTalab: uzs(cat.standartTalab)
    });
  }
  function locTur(tur) {
    const o = overlay();
    if (o) return o.turlar[tur];
    const x = KB.TURLAR[tur];
    return { nom: uzs(x.nom), sarlavha: uzs(x.sarlavha), tarif: uzs(x.tarif) };
  }
  function locDalil(k) { const o = overlay(); return o ? o.dalillar[k] : uzs(KB.DALILLAR[k]); }
  function locMQ() {
    const o = overlay();
    if (o) return o.murojaatQonuni;
    const n = uzs(KB.MUROJAAT_QONUNI.nom);
    return { nom: n, inline: n, mazmun: uzs(KB.MUROJAAT_QONUNI.mazmun) };
  }

  /* ---------- 1) YORDAMCHILAR ---------- */
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function norm(s) {
    return String(s || "").toLowerCase().replace(/[‘’ʻʼ`´]/g, "'");
  }
  function stripArticleNumbers(s) {
    // AI javobidan modda raqamlarini olib tashlash (xavfsizlik chorasi)
    return String(s || "")
      .replace(/\d+[\s\-–]*(?:[‑-]?\s*)?(modda|moddasi|moddasiga|moddasining|band|bandi|qism|qismi)\w*/gi, "tegishli normasi")
      .replace(/(modda|moddasi)\s*\d+/gi, "tegishli normasi");
  }
  function todayStr() {
    const d = new Date();
    const p = function (n) { return (n < 10 ? "0" : "") + n; };
    return p(d.getDate()) + "." + p(d.getMonth() + 1) + "." + d.getFullYear() + T("doc.dateSuffix");
  }
  function sentence(s) {
    s = String(s || "").trim().replace(/\s+/g, " ");
    if (!s) return "";
    s = s.charAt(0).toUpperCase() + s.slice(1);
    if (!/[.!?…]$/.test(s)) s += ".";
    return s;
  }
  function toast(msg, kind) {
    const t = document.createElement("div");
    t.className = "toast " + (kind || "");
    t.textContent = msg;
    $("toasts").appendChild(t);
    setTimeout(function () { t.classList.add("hide"); }, 2800);
    setTimeout(function () { t.remove(); }, 3300);
  }

  function readForm() {
    const dalillar = Array.prototype.slice.call(document.querySelectorAll("input[name=dalil]:checked"))
      .map(function (c) { return c.value; });
    return {
      fish: $("fish").value.trim(),
      manzil: $("manzil").value.trim(),
      aloqa: $("aloqa").value.trim(),
      tur: $("tur").value,
      tavsif: $("tavsif").value.trim(),
      talab: $("talab").value.trim(),
      dalillar: dalillar,
      boshqa: $("boshqa").value.trim()
    };
  }

  /* ---------- 2) DEMO MA'LUMOTLAR ---------- */
  // Demo maʼlumotlar har bir til uchun js/i18n.js dagi DEMOS ichida
  function fillDemo(key) {
    const d = I18N.DEMOS[I18N.lang][key];
    $("fish").value = d.fish; $("manzil").value = d.manzil; $("aloqa").value = d.aloqa;
    $("tur").value = "auto"; $("tavsif").value = d.tavsif; $("talab").value = d.talab; $("boshqa").value = d.boshqa;
    document.querySelectorAll("input[name=dalil]").forEach(function (c) { c.checked = d.dalillar.indexOf(c.value) >= 0; });
    updateCounter();
    state.analysis = null;
    runAnalysis().then(function () { buildDocument(); });
  }

  /* ---------- 3) TAHLIL (LOKAL / DEMO MANTIQ) ---------- */
  function detectCategory(text) {
    const t = norm(text);
    let best = KB.UMUMIY, bestScore = 0;
    KB.TOIFALAR.forEach(function (c) {
      let s = 0;
      c.kalit.concat(KBI.KALIT[c.id] || []).forEach(function (k) { if (t.indexOf(k) >= 0) s += k.length > 5 ? 2 : 1; });
      if (s > bestScore) { bestScore = s; best = c; }
    });
    return { cat: best, score: bestScore };
  }

  function detectType(form) {
    if (form.tur !== "auto") return { tur: form.tur, auto: false };
    const t = norm(form.tavsif + " " + form.talab);
    let sh = 0, tk = 0;
    KB.TUR_KALITLARI.shikoyat.concat(KBI.SHIKOYAT).forEach(function (k) { if (t.indexOf(k) >= 0) sh++; });
    KB.TUR_KALITLARI.taklif.concat(KBI.TAKLIF).forEach(function (k) { if (t.indexOf(k) >= 0) tk++; });
    let tur = "ariza";
    if (tk > sh) tur = "taklif"; else if (sh > 0) tur = "shikoyat";
    return { tur: tur, auto: true };
  }

  function checkCompleteness(form, cat, tur) {
    const w = [];
    const fishWords = form.fish.split(/\s+/).filter(Boolean);
    // Har bir ogohlantirish "id" bilan saqlanadi; matni chiqarishda joriy tilga tarjima qilinadi (w.<id>.t / w.<id>.f)
    if (!form.fish) w.push({ lvl: "red", id: "fish_empty" });
    else if (fishWords.length < 3) w.push({ lvl: "yellow", id: "fish_short" });
    if (!form.manzil) w.push({ lvl: "red", id: "manzil_empty" });
    else if (form.manzil.length < 15 || !/\d/.test(form.manzil)) w.push({ lvl: "yellow", id: "manzil_short" });
    if (!form.aloqa) {
      w.push({ lvl: "red", id: "aloqa_empty" });
    } else {
      const isEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.aloqa);
      const digits = form.aloqa.replace(/\D/g, "");
      if (!isEmail && digits.length < 9) w.push({ lvl: "yellow", id: "aloqa_bad" });
    }
    if (!form.tavsif) w.push({ lvl: "red", id: "tavsif_empty" });
    else if (form.tavsif.length < 80) w.push({ lvl: "yellow", id: "tavsif_short" });
    if (!form.talab) w.push({ lvl: tur === "taklif" ? "yellow" : "red", id: "talab_empty" });
    if (form.tavsif && !/(\d|\b(yanvar|fevral|mart|aprel|may|iyun|iyul|avgust|sentyabr|oktyabr|noyabr|dekabr|january|february|march|april|june|july|august|september|october|november|december|yesterday|today|week|month)|\bkecha|\bbugun|hafta|oydan|kundan|yildan|январ|феврал|март|апрел|мая|июн|июл|август|сентябр|октябр|ноябр|декабр|вчера|сегодня|недел|месяц|дней|aydan|kúnnen|jıldan|búgin|keshe)/i.test(form.tavsif)) {
      w.push({ lvl: "yellow", id: "sana" });
    }
    if (!form.dalillar.length && !form.boshqa) w.push({ lvl: "yellow", id: "dalil_none" });
    if (form.dalillar.length || form.boshqa) (cat.dalillar || []).forEach(function (d) {
      if (form.dalillar.indexOf(d) < 0 && !(cat.id === "istemol" && d === "chek")) {
        w.push({ lvl: "yellow", id: "dalil_rec", dalil: d });
      }
    });
    if (form.tavsif) {
      cat.tekshir(norm(form.tavsif + " " + form.talab + " " + form.boshqa), form).forEach(function (x) { w.push(x); });
    }
    const red = w.filter(function (x) { return x.lvl === "red"; }).length;
    const yellow = w.length - red;
    const score = Math.max(0, Math.min(100, 100 - red * 25 - yellow * 7));
    const status = red ? "red" : (yellow ? "yellow" : "green");
    return { warnings: w, red: red, yellow: yellow, score: score, status: status };
  }

  function localAnalysis(form) {
    const det = detectCategory(form.tavsif + " " + form.talab);
    const cat = det.cat;
    const tt = detectType(form);
    return {
      source: "local",
      form: form,
      cat: cat,
      tur: tt.tur,
      turAuto: tt.auto,
      ai: null,            // AI javobi (agar boʻlsa) — oʻsha paytdagi tilda
      risk: checkCompleteness(form, cat, tt.tur)
    };
  }

  // Chizish uchun koʻrinish: bilimlar bazasi joriy tilda + AI natijasi ustidan
  function view(a) {
    const c = locCat(a.cat);
    const v = { cat: c, organ: c.organ, kimga: c.kimga, sabab: c.sabab, qoshimcha: c.qoshimcha, bosqich: c.bosqich, qonunlar: c.qonunlar, bayon: "", talablar: [] };
    if (a.ai) {
      Object.keys(a.ai).forEach(function (k) {
        const x = a.ai[k];
        if (x == null || x === "" || (Array.isArray(x) && !x.length)) return;
        v[k] = x;
      });
    }
    return v;
  }

  /* ---------- 4) AI NATIJASINI BIRLASHTIRISH ---------- */
  function mergeAI(base, ai) {
    const r = Object.assign({}, base, { source: "ai", ai: {} });
    if (ai.turi && KB.TURLAR[ai.turi] && base.turAuto) r.tur = ai.turi;
    if (ai.organ) r.ai.organ = stripArticleNumbers(ai.organ);
    if (ai.kimga) r.ai.kimga = stripArticleNumbers(ai.kimga);
    if (ai.sabab) r.ai.sabab = stripArticleNumbers(ai.sabab);
    if (Array.isArray(ai.qoshimcha)) r.ai.qoshimcha = ai.qoshimcha.map(stripArticleNumbers);
    if (Array.isArray(ai.bosqich)) r.ai.bosqich = ai.bosqich.map(stripArticleNumbers);
    if (Array.isArray(ai.qonunlar)) {
      r.ai.qonunlar = ai.qonunlar.filter(function (q) { return q && q.nom; }).map(function (q) {
        return { nom: stripArticleNumbers(q.nom), mazmun: stripArticleNumbers(q.mazmun || "") };
      }).filter(function (q) { return !/(murojaatlari to'g'risida|обращениях физических|appeals of individuals|múrájatları haqqında)/i.test(norm(q.nom)); });
    }
    if (ai.bayon) r.ai.bayon = stripArticleNumbers(ai.bayon);
    if (Array.isArray(ai.talablar)) r.ai.talablar = ai.talablar.map(stripArticleNumbers).filter(Boolean);
    // Qaytarilish xavfi har doim deterministik qoidalar bilan qayta tekshiriladi
    r.risk = checkCompleteness(base.form, base.cat, r.tur);
    return r;
  }

  const state = { analysis: null, busy: false };

  async function runAnalysis() {
    if (state.busy) return state.analysis;
    const form = readForm();
    let result = localAnalysis(form);
    if (AI.isEnabled() && form.tavsif) {
      state.busy = true; setBusy(true);
      try {
        const ai = await AI.analyze(form, I18N.lang);
        result = mergeAI(result, ai);
        toast(T("t.aiOk"), "ok");
      } catch (e) {
        console.warn("AI xatosi:", e);
        toast(T("t.aiFail", { err: e.message || e }), "warn");
      } finally {
        state.busy = false; setBusy(false);
      }
    }
    state.analysis = result;
    renderCards(result);
    return result;
  }

  function setBusy(b) {
    ["btnAnalyze", "btnGenerate"].forEach(function (id) { $(id).disabled = b; });
    $("btnAnalyze").innerHTML = b ? '<span class="spin"></span> ' + esc(T("btn.analyzing")) : esc(T("btn.analyze"));
  }

  /* ---------- 5) KARTOCHKALARNI CHIZISH ---------- */
  function renderCards(a, quiet) {
    const v = view(a);
    const turInfo = locTur(a.tur);
    // Kartochka 1
    $("card1Body").innerHTML =
      '<div class="tag-row"><span class="tag">' + esc(v.cat.nom) + '</span>' +
      (a.source === "ai" ? '<span class="tag ai">' + esc(T("tag.ai")) + '</span>' : '<span class="tag muted">' + esc(T("tag.local")) + '</span>') + '</div>' +
      '<div class="organ-main"><div class="lbl">' + esc(T("c1.organ")) + '</div><div class="val">' + esc(v.organ) + '</div></div>' +
      '<p class="why"><b>' + esc(T("c1.why")) + '</b> ' + esc(v.sabab) + '</p>' +
      (v.bosqich && v.bosqich.length ? '<div class="sub">' + esc(T("c1.steps")) + '</div><ol class="steps">' +
        v.bosqich.map(function (s) { return "<li>" + esc(s) + "</li>"; }).join("") + "</ol>" : "") +
      (v.qoshimcha.length ? '<div class="sub">' + esc(T("c1.extra")) + '</div><ul class="list">' +
        v.qoshimcha.map(function (s) { return "<li>" + esc(s) + "</li>"; }).join("") + "</ul>" : "");

    // Kartochka 2
    const ev = Object.keys(KB.DALILLAR).map(function (k) {
      const has = a.form.dalillar.indexOf(k) >= 0;
      const rec = (a.cat.dalillar || []).indexOf(k) >= 0;
      if (!has && !rec) return "";
      return '<li class="' + (has ? "ok" : "miss") + '"><span class="ico">' + (has ? "✓" : "!") + "</span>" + esc(locDalil(k)) +
        (has ? "" : ' <em>' + esc(T("c2.recommended")) + '</em>') + "</li>";
    }).join("") + (a.form.boshqa ? '<li class="ok"><span class="ico">✓</span>' + esc(uzs(a.form.boshqa)) + "</li>" : "");
    const way = function (k) { return '<div class="way"><b>' + esc(T("way." + k + ".t")) + "</b><span>" + esc(T("way." + k + ".d")) + "</span></div>"; };
    $("card2Body").innerHTML =
      '<div class="type-box"><div><div class="lbl">' + esc(T("c2.type")) + (a.turAuto ? esc(T("c2.auto")) : "") + '</div>' +
      '<div class="val big">' + esc(turInfo.nom) + '</div></div><p>' + esc(turInfo.tarif) + "</p></div>" +
      '<div class="sub">' + esc(T("c2.ways")) + '</div>' +
      '<div class="ways">' + way("e") + way("w") + way("o") + "</div>" +
      '<div class="sub">' + esc(T("c2.evidence")) + '</div>' +
      (ev ? '<ul class="evidence">' + ev + "</ul>" : '<p class="muted-p">' + esc(T("c2.noEvidence")) + '</p>') +
      '<p class="hint">' + esc(T("c2.idHint")) + '</p>';

    // Kartochka 3
    const mq = locMQ();
    const laws = [{ nom: mq.nom, mazmun: mq.mazmun }].concat(v.qonunlar);
    const r = a.risk;
    $("card3Body").innerHTML =
      '<div class="sub first">' + esc(T("c3.basis")) + '</div><ul class="laws">' +
      laws.map(function (q) { return '<li><div class="law-name">' + esc(q.nom) + '</div><div class="law-txt">' + esc(q.mazmun) + "</div></li>"; }).join("") +
      '</ul><p class="hint">' + T("c3.lexHint") + '</p>' +
      '<div class="sub">' + esc(T("c3.check")) + '</div>' +
      '<div class="risk ' + r.status + '"><div class="meter"><div class="bar" style="width:' + r.score + '%"></div></div>' +
      '<div class="risk-head"><span class="dot"></span><b>' + esc(T("risk." + r.status)) + '</b><span class="score">' + r.score + '/100</span></div></div>' +
      (r.warnings.length ? '<ul class="warns">' + r.warnings.map(function (x) {
        const vars = x.dalil ? { name: locDalil(x.dalil) } : null;
        return '<li class="' + x.lvl + '"><div class="w-t">' + (x.lvl === "red" ? "⛔ " : "⚠ ") + esc(T("w." + x.id + ".t", vars)) +
          '</div><div class="w-f">' + esc(T("w." + x.id + ".f", vars)) + "</div></li>";
      }).join("") + "</ul>" : '<p class="ok-p">' + esc(T("c3.allOk")) + '</p>');

    if (!quiet) { markFilled("card1"); markFilled("card2"); markFilled("card3"); }
    $("riskBadge").className = "badge " + r.status;
    $("riskBadge").textContent = T("badge." + r.status);
  }
  function markFilled(id) {
    const el = $(id); el.classList.remove("empty"); el.classList.remove("flash"); void el.offsetWidth; el.classList.add("flash");
  }

  /* ---------- 6) HUJJAT SHAKLLANTIRISH ---------- */
  function ph(v, label) {
    return v ? esc(v) : '<span class="missing">[' + esc(label) + ']</span>';
  }

  function buildDocument() {
    const a = state.analysis;
    if (!a) return;
    const v = view(a);
    const f = a.form;
    const turInfo = locTur(a.tur);
    const mq = locMQ();
    const laws = [mq].concat(v.qonunlar);
    const fish = uzs(f.fish);

    const bayon = v.bayon ? sentence(v.bayon) : sentence(uzs(f.tavsif));
    const talablar = (v.talablar && v.talablar.length ? v.talablar :
      (f.talab ? uzs(f.talab).split(/\n|;/).map(function (s) { return s.trim(); }).filter(Boolean) : []))
      .map(sentence);

    let lawSentence = "";
    if (v.qonunlar.length) {
      lawSentence = T("doc.law", {
        laws: v.qonunlar.map(function (q) { return q.nom; }).join(T("doc.lawJoin")),
        mazmun: lowerFirst(v.qonunlar[0].mazmun.replace(/\.$/, ""))
      });
    }
    const procSentence = T("doc.proc", { law: mq.inline || mq.nom });
    const ask = a.tur === "taklif" ? T("doc.askTaklif") : T("doc.ask");

    const items = talablar.length ? talablar.slice() : ['<span class="missing">[' + esc(T("doc.noTalab", { x: v.cat.standartTalab })) + ']</span>'];
    if (a.tur === "shikoyat") items.push(T("doc.itemShikoyat"));
    items.push(T("doc.itemReply"));

    const ilovalar = f.dalillar.map(locDalil);
    if (f.boshqa) ilovalar.push(uzs(f.boshqa));

    const phFish = ph(fish, T("ph.d.fish"));
    const html = [];
    html.push('<p class="d-right"><b>' + esc(v.kimga) + "</b></p>");
    html.push('<p class="d-right">' + T("doc.from", { fish: phFish }) + "</p>");
    html.push('<p class="d-right">' + esc(T("doc.addr")) + ph(uzs(f.manzil), T("ph.d.manzil")) + "</p>");
    html.push('<p class="d-right">' + esc(T("doc.contact")) + ph(f.aloqa, T("ph.d.aloqa")) + "</p>");
    html.push('<p class="d-gap"></p>');
    html.push('<p class="d-center d-title"><b>' + esc(turInfo.sarlavha) + "</b></p>");
    html.push('<p class="d-center"><i>' + esc(T("doc.about", { mavzu: v.cat.mavzu })) + "</i></p>");
    html.push('<p class="d-gap"></p>');
    html.push('<p class="d-just">' + T("doc.intro", { fish: phFish, mavzu: esc(v.cat.mavzu) }) + "</p>");
    html.push('<p class="d-just">' + (bayon ? esc(bayon) : '<span class="missing">[' + esc(T("doc.noBayon")) + ']</span>') + "</p>");
    if (lawSentence) html.push('<p class="d-just">' + esc(lawSentence) + "</p>");
    html.push('<p class="d-just">' + esc(procSentence) + "</p>");
    html.push('<p class="d-just">' + esc(ask) + "</p>");
    items.forEach(function (it, i) {
      html.push('<p class="d-just d-li">' + (i + 1) + ". " + (it.indexOf("<span") === 0 ? it : esc(it)) + "</p>");
    });
    html.push('<p class="d-gap"></p>');
    if (ilovalar.length) {
      html.push("<p><b>" + esc(T("doc.att")) + "</b></p>");
      ilovalar.forEach(function (x, i) { html.push('<p class="d-li">' + (i + 1) + ". " + esc(T("doc.attItem", { x: x })) + "</p>"); });
    } else {
      html.push("<p>" + esc(T("doc.attNone")) + "</p>");
    }
    html.push('<p class="d-gap"></p>');
    html.push('<p class="d-sign">' + esc(T("doc.date", { d: todayStr() })) + "</p>");
    html.push('<p class="d-sign">' + esc(T("doc.sign")) + "&nbsp;&nbsp; " + ph(shortName(fish), T("ph.d.fish")) + "</p>");

    $("docPaper").innerHTML = html.join("\n");
    $("docPaper").setAttribute("data-type", a.tur);
    $("card4").classList.remove("empty");
    $("docActions").classList.remove("disabled");
    $("docMeta").innerHTML = '<span class="badge ' + a.risk.status + '">' + esc(turInfo.nom) + "</span> " + esc(T("docMeta." + a.risk.status));
    $("legalBasisNote").textContent = T("legalBasis") + laws.map(function (q) {
      return q.nom.replace(/^(Oʻzbekiston Respublikasining |Ózbekstan Respublikasınıń )/, "");
    }).join("; ");
    state.docBuilt = true;
  }

  function lowerFirst(s) { s = String(s || ""); return s.charAt(0).toLowerCase() + s.slice(1); }
  function shortName(fish) {
    const p = String(fish || "").split(/\s+/).filter(Boolean);
    if (p.length < 2) return fish;
    return p[0] + " " + p.slice(1).map(function (x) { return x.charAt(0).toUpperCase() + "."; }).join("");
  }

  /* ---------- 7) NUSXA / DOCX / CHOP ETISH ---------- */
  function docReady() {
    if (!$("docPaper").textContent.trim() || $("card4").classList.contains("empty")) {
      toast(T("t.needDoc"), "warn");
      return false;
    }
    return true;
  }

  function paperLines() {
    // Tahrirlangan hujjatdan paragraf ro'yxatini olish (har biri: matn + uslub)
    const out = [];
    $("docPaper").childNodes.forEach(function (n) {
      if (n.nodeType === 3) { if (n.textContent.trim()) out.push({ text: n.textContent.trim(), cls: "" }); return; }
      if (n.nodeType !== 1) return;
      const cls = n.className || "";
      const bold = !!n.querySelector("b,strong") && n.textContent.trim() === (n.querySelector("b,strong").textContent || "").trim();
      const text = n.innerText.replace(/ /g, " ");
      out.push({ text: text, cls: cls, bold: bold, gap: cls.indexOf("d-gap") >= 0 });
    });
    return out;
  }

  async function copyDoc() {
    if (!docReady()) return;
    const txt = $("docPaper").innerText;
    try {
      await navigator.clipboard.writeText(txt);
    } catch (e) {
      const ta = document.createElement("textarea");
      ta.value = txt; document.body.appendChild(ta); ta.select();
      document.execCommand("copy"); ta.remove();
    }
    toast(T("t.copied"), "ok");
  }

  function downloadDocx() {
    if (!docReady()) return;
    const D = window.docx;
    if (!D) { toast(T("t.docxMissing"), "warn"); return; }
    const FONT = "Times New Roman";
    const paras = paperLines().map(function (l) {
      if (l.gap) return new D.Paragraph({ children: [new D.TextRun({ text: "", font: FONT, size: 28 })] });
      let align = D.AlignmentType.LEFT;
      if (l.cls.indexOf("d-right") >= 0) align = D.AlignmentType.RIGHT;
      else if (l.cls.indexOf("d-center") >= 0) align = D.AlignmentType.CENTER;
      else if (l.cls.indexOf("d-just") >= 0) align = D.AlignmentType.JUSTIFIED;
      const isTitle = l.cls.indexOf("d-title") >= 0;
      const lines = l.text.split("\n");
      const runs = lines.map(function (ln, i) {
        return new D.TextRun({ text: ln, font: FONT, size: isTitle ? 32 : 28, bold: l.bold || isTitle, break: i > 0 ? 1 : 0 });
      });
      return new D.Paragraph({
        alignment: align,
        children: runs,
        spacing: { after: 80, line: 300 },
        indent: (l.cls.indexOf("d-just") >= 0 && l.cls.indexOf("d-li") < 0) ? { firstLine: 709 } : (l.cls.indexOf("d-li") >= 0 ? { left: 360 } : undefined)
      });
    });
    const doc = new D.Document({
      creator: "E-murojaat",
      title: "Rasmiy murojaat",
      sections: [{
        properties: { page: { margin: { top: 1134, bottom: 1134, left: 1701, right: 850 } } },
        children: paras
      }]
    });
    D.Packer.toBlob(doc).then(function (blob) {
      const a = document.createElement("a");
      const d = new Date();
      a.href = URL.createObjectURL(blob);
      a.download = "murojaat_" + d.toISOString().slice(0, 10) + ".docx";
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(function () { URL.revokeObjectURL(a.href); }, 4000);
      toast(T("t.docxOk"), "ok");
    }).catch(function (e) { console.error(e); toast(T("t.docxErr", { err: e.message }), "warn"); });
  }

  function printDoc() {
    if (!docReady()) return;
    window.print();
  }

  /* ---------- 8) HODISALAR ---------- */
  function updateCounter() { $("tavsifCount").textContent = T("counter", { n: $("tavsif").value.length }); }

  function updateAiMode() {
    const on = AI.isEnabled();
    $("aiMode").className = "mode " + (on ? "on" : "off");
    $("aiMode").textContent = on ? T("mode.ai") : T("mode.demo");
  }

  /* ---------- 9) TITUL VARAQ va OʻTISHLAR ---------- */
  const reduceMotion = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  function splitTitle() {
    // "E-murojaat" harflarini alohida <span> larga boʻlib, ketma-ket chiqarish (motion)
    const el = document.querySelector(".land-title .lt");
    if (!el || el.getAttribute("data-split")) return;
    const txt = el.textContent;
    el.innerHTML = txt.split("").map(function (ch, i) {
      return '<span class="ch" aria-hidden="true" style="--i:' + i + '">' + esc(ch) + "</span>";
    }).join("");
    el.setAttribute("data-split", "1");
  }

  function replayLanding() {
    // Animatsiyalarni qayta ishga tushirish (bosh sahifaga qaytilganda)
    const l = $("landing");
    l.classList.remove("leaving");
    const clone = l.cloneNode(true);
    l.parentNode.replaceChild(clone, l);
    bindLanding();
  }

  function enterApp(after) {
    const land = $("landing"), app = $("appShell");
    const show = function () {
      land.hidden = true;
      document.body.classList.remove("on-landing");
      app.hidden = false;
      app.classList.remove("entering"); void app.offsetWidth; app.classList.add("entering");
      window.scrollTo(0, 0);
      try { history.replaceState(null, "", "#murojaat"); } catch (e) { /* file:// */ }
      if (after) after();
    };
    if (reduceMotion) { show(); return; }
    land.classList.add("leaving");
    setTimeout(show, 650);
  }

  function goHome() {
    $("appShell").hidden = true;
    $("landing").hidden = false;
    document.body.classList.add("on-landing");
    try { history.replaceState(null, "", location.pathname + location.search); } catch (e) { /* file:// */ }
    replayLanding();
    window.scrollTo(0, 0);
  }

  function bindLanding() {
    $("btnStart").addEventListener("click", function () { enterApp(function () { $("fish").focus({ preventScroll: true }); }); });
    $("btnLandDemo").addEventListener("click", function () {
      enterApp(function () { fillDemo("ishhaqi"); });
    });
    bindLangButtons($("landing"));
    // Sichqoncha harakatiga yengil parallaks
    const art = document.querySelector("#landing .arch-art");
    if (art && !reduceMotion) {
      $("landing").addEventListener("mousemove", function (e) {
        if ($("landing").classList.contains("leaving")) return;
        const x = (e.clientX / window.innerWidth - 0.5) * 14;
        const y = (e.clientY / window.innerHeight - 0.5) * 10;
        art.style.transform = "translate(" + x.toFixed(1) + "px," + y.toFixed(1) + "px)";
      });
    }
    I18N.apply($("landing"));
  }

  function bindLangButtons(root) {
    root.querySelectorAll("[data-lang]").forEach(function (b) {
      b.addEventListener("click", function () { I18N.setLang(b.getAttribute("data-lang")); });
    });
  }

  // Til almashganda dinamik qismlarni qayta chizish
  document.addEventListener("em:langchange", function () {
    updateCounter(); updateAiMode();
    if (state.analysis) {
      renderCards(state.analysis, true);
      if (state.docBuilt) buildDocument();
    }
  });

  document.addEventListener("DOMContentLoaded", function () {
    I18N.apply();
    splitTitle();
    bindLanding();
    bindLangButtons($("appShell"));
    $("btnHome").addEventListener("click", goHome);
    $("btnHome2").addEventListener("click", goHome);
    if (location.hash === "#murojaat") {
      $("landing").hidden = true; document.body.classList.remove("on-landing"); $("appShell").hidden = false;
    }

    document.querySelectorAll("[data-demo]").forEach(function (b) {
      b.addEventListener("click", function () {
        fillDemo(b.getAttribute("data-demo"));
        toast(T("t.demo", { name: b.textContent.trim() }), "ok");
      });
    });
    $("btnAnalyze").addEventListener("click", function () {
      runAnalysis().then(function () {
        if (window.innerWidth < 1024) $("card1").scrollIntoView({ behavior: "smooth" });
      });
    });
    $("btnGenerate").addEventListener("click", function () {
      runAnalysis().then(function () {
        buildDocument();
        $("card4").scrollIntoView({ behavior: "smooth", block: "start" });
        toast(T("t.docReady"), "ok");
      });
    });
    $("btnReset").addEventListener("click", function () {
      $("form").reset(); updateCounter(); state.analysis = null; state.docBuilt = false;
      ["card1", "card2", "card3", "card4"].forEach(function (id) { $(id).classList.add("empty"); });
      ["card1Body", "card2Body", "card3Body"].forEach(function (id) { $(id).innerHTML = $(id).getAttribute("data-empty"); I18N.apply($(id)); });
      $("docPaper").innerHTML = ""; $("docActions").classList.add("disabled"); $("docMeta").textContent = "";
      $("riskBadge").className = "badge"; $("riskBadge").textContent = "—";
    });
    $("tavsif").addEventListener("input", updateCounter);
    $("btnCopy").addEventListener("click", copyDoc);
    $("btnDocx").addEventListener("click", downloadDocx);
    $("btnPrint").addEventListener("click", printDoc);

    // AI sozlamalari oynasi
    $("btnAi").addEventListener("click", function () {
      $("apiKey").value = AI.getKey(); $("aiModal").classList.add("open");
    });
    $("aiClose").addEventListener("click", function () { $("aiModal").classList.remove("open"); });
    $("aiSave").addEventListener("click", function () {
      AI.setKey($("apiKey").value.trim()); updateAiMode(); $("aiModal").classList.remove("open");
      toast(AI.isEnabled() ? T("t.aiOn") : T("t.aiOff"), "ok");
    });
    $("aiClear").addEventListener("click", function () {
      AI.setKey(""); $("apiKey").value = ""; updateAiMode(); $("aiModal").classList.remove("open");
      toast(T("t.keyRemoved"), "ok");
    });

    ["card1Body", "card2Body", "card3Body"].forEach(function (id) { $(id).setAttribute("data-empty", $(id).innerHTML); });
    updateCounter(); updateAiMode();
  });
})();
